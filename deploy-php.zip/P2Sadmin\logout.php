<?php
/**
 * CRM Logout - Pillars to Home
 */
require_once '../includes/auth.php';
logout();
?>
