<?php
/**
 * CRM Analytics - Pillars to Home
 */
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireLogin();

// Fetch Stats
$total_leads = $pdo->query("SELECT COUNT(*) FROM leads")->fetchColumn();
$abandoned_leads = $pdo->query("SELECT COUNT(*) FROM leads WHERE status = 'abandoned'")->fetchColumn();
$submitted_leads = $pdo->query("SELECT COUNT(*) FROM leads WHERE status = 'submitted'")->fetchColumn();
$hot_leads = $pdo->query("SELECT COUNT(*) FROM leads WHERE is_hot = 1")->fetchColumn();

// Source Distribution
$sources = $pdo->query("SELECT utm_source, COUNT(*) as count FROM leads GROUP BY utm_source ORDER BY count DESC")->fetchAll();

// Intent Distribution
$intents = $pdo->query("SELECT intent_level, COUNT(*) as count FROM leads GROUP BY intent_level ORDER BY count DESC")->fetchAll();

// Activity Trends (Last 7 days)
$trends = $pdo->query("SELECT DATE(created_at) as date, COUNT(*) as count FROM leads WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY date ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Analytics | Pillars to Home CRM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3 { font-family: 'DM Serif Display', serif; }
    </style>
</head>
<body class="bg-gray-50 text-gray-900 flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-72 bg-white border-r border-gray-100 flex flex-col p-8 fixed h-full">
        <div class="mb-12">
            <h1 class="text-2xl font-bold tracking-tighter">CRM DASHBOARD</h1>
            <p class="text-gray-400 text-[10px] uppercase tracking-widest font-bold mt-2">Pillars to Home</p>
        </div>
        
        <nav class="flex-1 space-y-4">
            <a href="dashboard.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                Dashboard
            </a>
            <a href="leads.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                Leads Management
            </a>
            <a href="properties.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                Properties
            </a>
            <a href="analytics.php" class="flex items-center gap-4 text-black font-bold p-4 bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                Analytics
            </a>
        </nav>
        
        <div class="mt-auto pt-8 border-t border-gray-100">
            <a href="logout.php" class="text-xs font-bold text-red-500 uppercase tracking-widest hover:text-red-700 transition">Logout</a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 ml-72 p-12">
        <header class="mb-12">
            <h2 class="text-4xl mb-2">CRM Intelligence</h2>
            <p class="text-gray-400">Deep insights into lead behavior and marketing performance.</p>
        </header>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-12">
            <!-- Lead Trends -->
            <div class="bg-white p-10 rounded-[40px] shadow-sm border border-gray-100">
                <h3 class="text-2xl mb-8">Lead Volume (Last 7 Days)</h3>
                <canvas id="trendsChart" height="200"></canvas>
            </div>

            <!-- Intent Distribution -->
            <div class="bg-white p-10 rounded-[40px] shadow-sm border border-gray-100">
                <h3 class="text-2xl mb-8">Intent Distribution</h3>
                <canvas id="intentChart" height="200"></canvas>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <!-- Source Performance -->
            <div class="lg:col-span-1 bg-white p-10 rounded-[40px] shadow-sm border border-gray-100">
                <h3 class="text-2xl mb-8">Top Traffic Sources</h3>
                <div class="space-y-6">
                    <?php foreach ($sources as $source): ?>
                    <div class="flex justify-between items-center">
                        <p class="text-sm font-bold uppercase tracking-widest text-gray-400"><?= $source['utm_source'] ?: 'Direct' ?></p>
                        <p class="text-lg font-bold"><?= $source['count'] ?></p>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Conversion Funnel -->
            <div class="lg:col-span-2 bg-white p-10 rounded-[40px] shadow-sm border border-gray-100">
                <h3 class="text-2xl mb-8">Conversion Funnel</h3>
                <div class="space-y-12">
                    <div>
                        <div class="flex justify-between mb-2">
                            <p class="text-xs font-bold uppercase tracking-widest text-gray-400">Total Inquiries</p>
                            <p class="text-sm font-bold"><?= $total_leads ?></p>
                        </div>
                        <div class="w-full bg-gray-50 h-3 rounded-full overflow-hidden">
                            <div class="bg-black h-full" style="width: 100%"></div>
                        </div>
                    </div>
                    <div>
                        <div class="flex justify-between mb-2">
                            <p class="text-xs font-bold uppercase tracking-widest text-gray-400">Full Submissions</p>
                            <p class="text-sm font-bold"><?= $submitted_leads ?></p>
                        </div>
                        <div class="w-full bg-gray-50 h-3 rounded-full overflow-hidden">
                            <div class="bg-green-500 h-full" style="width: <?= $total_leads > 0 ? ($submitted_leads / $total_leads) * 100 : 0 ?>%"></div>
                        </div>
                    </div>
                    <div>
                        <div class="flex justify-between mb-2">
                            <p class="text-xs font-bold uppercase tracking-widest text-gray-400">Hot Leads (High Intent)</p>
                            <p class="text-sm font-bold"><?= $hot_leads ?></p>
                        </div>
                        <div class="w-full bg-gray-50 h-3 rounded-full overflow-hidden">
                            <div class="bg-orange-500 h-full" style="width: <?= $total_leads > 0 ? ($hot_leads / $total_leads) * 100 : 0 ?>%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        // Trends Chart
        const trendsCtx = document.getElementById('trendsChart').getContext('2d');
        new Chart(trendsCtx, {
            type: 'line',
            data: {
                labels: <?= json_encode(array_column($trends, 'date')) ?>,
                datasets: [{
                    label: 'Leads',
                    data: <?= json_encode(array_column($trends, 'count')) ?>,
                    borderColor: '#000',
                    tension: 0.4,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });

        // Intent Chart
        const intentCtx = document.getElementById('intentChart').getContext('2d');
        new Chart(intentCtx, {
            type: 'doughnut',
            data: {
                labels: <?= json_encode(array_column($intents, 'intent_level')) ?>,
                datasets: [{
                    data: <?= json_encode(array_column($intents, 'count')) ?>,
                    backgroundColor: ['#000', '#f97316', '#94a3b8']
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: 'bottom' } }
            }
        });
    </script>
</body>
</html>
