<?php
/**
 * CRM Login - Pillars to Home
 */
require_once '../includes/auth.php';

if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username']);
    $password = $_POST['password'];
    
    if (login($username, $password)) {
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Invalid username or password';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRM Login | Pillars to Home</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1 { font-family: 'DM Serif Display', serif; }
    </style>
</head>
<body class="bg-gray-50 h-screen flex items-center justify-center px-6">
    <div class="max-w-md w-full bg-white rounded-[40px] p-12 shadow-2xl border border-gray-100">
        <div class="text-center mb-10">
            <h1 class="text-3xl mb-2">PILLARS TO HOME</h1>
            <p class="text-gray-400 text-xs uppercase tracking-widest font-bold">CRM Access</p>
        </div>
        
        <?php if ($error): ?>
        <div class="bg-red-50 text-red-600 p-4 rounded-2xl text-sm mb-8 text-center font-medium">
            <?= $error ?>
        </div>
        <?php endif; ?>

        <form method="POST" class="space-y-6">
            <div>
                <label class="text-[10px] uppercase tracking-widest font-bold text-gray-400 mb-2 block">Username</label>
                <input type="text" name="username" required class="w-full bg-gray-50 border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-black outline-none transition" placeholder="admin">
            </div>
            <div>
                <label class="text-[10px] uppercase tracking-widest font-bold text-gray-400 mb-2 block">Password</label>
                <input type="password" name="password" required class="w-full bg-gray-50 border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-black outline-none transition" placeholder="••••••••">
            </div>
            <button type="submit" class="w-full bg-black text-white py-5 rounded-2xl font-bold hover:bg-gray-800 transition shadow-xl mt-4">Login to CRM</button>
        </form>
        
        <div class="mt-10 text-center text-gray-400 text-xs">
            &copy; <?= date('Y') ?> Pillars to Home. Secure Access Only.
        </div>
    </div>
</body>
</html>
