<?php
/**
 * API: Track Event - Pillars to Home
 */
header('Content-Type: application/json');
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
    exit;
}

$session_id = session_id();
$page_url = isset($input['page_url']) ? sanitize($input['page_url']) : null;
$event_type = isset($input['event_type']) ? sanitize($input['event_type']) : null;
$event_value = isset($input['event_value']) ? sanitize($input['event_value']) : null;

try {
    // Log activity
    $stmt = $pdo->prepare("INSERT INTO activity_logs (session_id, page_url, event_type, event_value) VALUES (?, ?, ?, ?)");
    $stmt->execute([$session_id, $page_url, $event_type, $event_value]);

    // Update session last activity
    $stmt = $pdo->prepare("UPDATE sessions SET last_activity = CURRENT_TIMESTAMP WHERE session_id = ?");
    $stmt->execute([$session_id]);

    // Check if session exists, if not create it
    $stmt = $pdo->prepare("SELECT id FROM sessions WHERE session_id = ?");
    $stmt->execute([$session_id]);
    if (!$stmt->fetch()) {
        $stmt = $pdo->prepare("INSERT INTO sessions (session_id, ip_address, user_agent) VALUES (?, ?, ?)");
        $stmt->execute([$session_id, $_SERVER['REMOTE_ADDR'], $_SERVER['HTTP_USER_AGENT']]);
    }

    // If lead exists for this session, update its score
    $stmt = $pdo->prepare("SELECT id FROM leads WHERE session_id = ?");
    $stmt->execute([$session_id]);
    $lead = $stmt->fetch();
    if ($lead) {
        runAutomation($lead['id']);
    }

    echo json_encode(['status' => 'success']);
} catch (PDOException $e) {
    logSystem('error', "API Track Event Error: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Database error']);
}
?>
