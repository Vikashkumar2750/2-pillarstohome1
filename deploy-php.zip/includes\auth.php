<?php
/**
 * Auth Logic - Pillars to Home
 */
require_once 'db.php';

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Check if user is admin
 */
function isAdmin() {
    return isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Require login to access page
 */
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /P2Sadmin/index.php');
        exit;
    }
}

/**
 * Require admin role
 */
function requireAdmin() {
    requireLogin();
    if (!isAdmin()) {
        header('Location: /P2Sadmin/dashboard.php?error=unauthorized');
        exit;
    }
}

/**
 * Login function
 */
function login($username, $password) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_username'] = $user['username'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_full_name'] = $user['full_name'];
        return true;
    }
    return false;
}

/**
 * Logout function
 */
function logout() {
    session_unset();
    session_destroy();
    header('Location: /P2Sadmin/index.php');
    exit;
}
?>
