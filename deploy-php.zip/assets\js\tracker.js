/**
 * User Behavior Tracker - Pillars to Home
 */
(function() {
    const trackEvent = async (type, value = '') => {
        try {
            await fetch('api/track_event.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    page_url: window.location.href,
                    event_type: type,
                    event_value: value
                })
            });
        } catch (err) {
            console.error('Tracking error:', err);
        }
    };

    // Track page view
    trackEvent('view');

    // Track scroll depth
    let maxScroll = 0;
    window.addEventListener('scroll', () => {
        const scrollPercent = Math.round((window.scrollY + window.innerHeight) / document.documentElement.scrollHeight * 100);
        if (scrollPercent > maxScroll && scrollPercent % 25 === 0) {
            maxScroll = scrollPercent;
            trackEvent('scroll', `${maxScroll}%`);
        }
    });

    // Track clicks on important elements
    document.addEventListener('click', (e) => {
        const target = e.target.closest('a, button');
        if (target) {
            const label = target.innerText || target.getAttribute('aria-label') || target.id || 'unlabeled';
            trackEvent('click', label.trim());
        }
    });

    // Track time spent (every 30 seconds)
    let timeSpent = 0;
    setInterval(() => {
        timeSpent += 30;
        trackEvent('time_spent', `${timeSpent}s`);
    }, 30000);

    // Track exit intent
    document.addEventListener('mouseleave', (e) => {
        if (e.clientY < 0) {
            trackEvent('exit_intent');
        }
    });
})();
