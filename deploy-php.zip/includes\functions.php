<?php
/**
 * Common Functions - Pillars to Home
 */
require_once 'db.php';

/**
 * Sanitize input
 */
function sanitize($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}

/**
 * Get lead score based on behavior
 */
function calculateLeadScore($lead_id) {
    global $pdo;
    $score = 0;
    
    // Check page views
    $stmt = $pdo->prepare("SELECT COUNT(*) as views FROM activity_logs al 
                           JOIN leads l ON al.session_id = l.session_id 
                           WHERE l.id = ? AND al.event_type = 'view'");
    $stmt->execute([$lead_id]);
    $views = $stmt->fetch()['views'];
    $score += ($views * 5); // 5 points per page view
    
    // Check property views
    $stmt = $pdo->prepare("SELECT COUNT(*) as prop_views FROM activity_logs al 
                           JOIN leads l ON al.session_id = l.session_id 
                           WHERE l.id = ? AND al.event_type = 'view' AND al.page_url LIKE '%property.php%'");
    $stmt->execute([$lead_id]);
    $prop_views = $stmt->fetch()['prop_views'];
    $score += ($prop_views * 10); // 10 points per property view
    
    // Check if form submitted
    $stmt = $pdo->prepare("SELECT status FROM leads WHERE id = ?");
    $stmt->execute([$lead_id]);
    $status = $stmt->fetch()['status'];
    if ($status === 'submitted') {
        $score += 50;
    }
    
    return $score;
}

/**
 * Automation Logic: Update lead status and intent
 */
function runAutomation($lead_id) {
    global $pdo;
    $score = calculateLeadScore($lead_id);
    
    $intent = 'low';
    if ($score > 100) $intent = 'high';
    elseif ($score > 50) $intent = 'medium';
    
    $is_hot = ($score > 150) ? 1 : 0;
    
    $stmt = $pdo->prepare("UPDATE leads SET score = ?, intent_level = ?, is_hot = ? WHERE id = ?");
    $stmt->execute([$score, $intent, $is_hot, $lead_id]);
    
    // Log event if hot lead
    if ($is_hot) {
        $stmt = $pdo->prepare("INSERT INTO lead_events (lead_id, event_type, event_data) VALUES (?, 'automation', 'Marked as Hot Lead')");
        $stmt->execute([$lead_id]);
    }
}

/**
 * Get property details
 */
function getProperty($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM properties WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

/**
 * Get featured properties
 */
function getFeaturedProperties($limit = 3) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM properties WHERE is_featured = 1 LIMIT ?");
    $stmt->execute([$limit]);
    return $stmt->fetchAll();
}

/**
 * Format currency
 */
function formatCurrency($amount) {
    return '₹' . number_format($amount, 0, '.', ',');
}

/**
 * Log system event
 */
function logSystem($level, $message) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO system_logs (log_level, message) VALUES (?, ?)");
    $stmt->execute([$level, $message]);
}
?>
