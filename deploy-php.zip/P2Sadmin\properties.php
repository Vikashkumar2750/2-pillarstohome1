<?php
/**
 * CRM Properties Management - Pillars to Home
 */
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireLogin();

// Fetch all properties
$stmt = $pdo->query("SELECT * FROM properties ORDER BY created_at DESC");
$properties = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Properties Management | Pillars to Home CRM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3 { font-family: 'DM Serif Display', serif; }
    </style>
</head>
<body class="bg-gray-50 text-gray-900 flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-72 bg-white border-r border-gray-100 flex flex-col p-8 fixed h-full">
        <div class="mb-12">
            <h1 class="text-2xl font-bold tracking-tighter">CRM DASHBOARD</h1>
            <p class="text-gray-400 text-[10px] uppercase tracking-widest font-bold mt-2">Pillars to Home</p>
        </div>
        
        <nav class="flex-1 space-y-4">
            <a href="dashboard.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                Dashboard
            </a>
            <a href="leads.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                Leads Management
            </a>
            <a href="properties.php" class="flex items-center gap-4 text-black font-bold p-4 bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                Properties
            </a>
            <a href="analytics.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                Analytics
            </a>
        </nav>
        
        <div class="mt-auto pt-8 border-t border-gray-100">
            <a href="logout.php" class="text-xs font-bold text-red-500 uppercase tracking-widest hover:text-red-700 transition">Logout</a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 ml-72 p-12">
        <header class="flex justify-between items-end mb-12">
            <div>
                <h2 class="text-4xl mb-2">Properties Portfolio</h2>
                <p class="text-gray-400">Manage your luxury real estate listings across the globe.</p>
            </div>
            <button class="bg-black text-white px-8 py-3 rounded-2xl font-bold hover:bg-gray-800 transition shadow-lg flex items-center gap-2">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                Add Property
            </button>
        </header>

        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
            <?php foreach ($properties as $prop): ?>
            <div class="bg-white rounded-[40px] shadow-sm border border-gray-100 overflow-hidden group">
                <div class="relative h-64 overflow-hidden">
                    <img src="<?= $prop['image'] ?>" alt="<?= $prop['title'] ?>" class="w-full h-full object-cover group-hover:scale-110 transition duration-700">
                    <div class="absolute top-6 right-6">
                        <span class="px-4 py-2 rounded-full bg-white/90 backdrop-blur text-[10px] font-bold uppercase tracking-widest">
                            <?= $prop['type'] ?>
                        </span>
                    </div>
                </div>
                <div class="p-8">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <h3 class="text-xl mb-1"><?= $prop['title'] ?></h3>
                            <p class="text-xs text-gray-400 flex items-center gap-1">
                                <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                                <?= $prop['location'] ?>
                            </p>
                        </div>
                        <p class="text-lg font-bold"><?= $prop['price'] ?></p>
                    </div>
                    <div class="flex justify-between items-center pt-6 border-t border-gray-50">
                        <div class="flex gap-4 text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                            <span><?= $prop['beds'] ?> Beds</span>
                            <span><?= $prop['baths'] ?> Baths</span>
                            <span><?= number_format($prop['sqft']) ?> Sqft</span>
                        </div>
                        <div class="flex gap-2">
                            <button class="p-2 text-gray-400 hover:text-black transition">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                            </button>
                            <button class="p-2 text-gray-400 hover:text-red-500 transition">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>
</body>
</html>
