/**
 * Real-Time Lead Capture - Pillars to Home
 */
(function() {
    const saveLead = async (data) => {
        try {
            await fetch('api/save_lead.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        } catch (err) {
            console.error('Lead capture error:', err);
        }
    };

    // Debounce function
    const debounce = (func, wait) => {
        let timeout;
        return function(...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    };

    // Auto-save on input
    const handleInput = debounce((e) => {
        const form = e.target.closest('form');
        if (!form) return;

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        data.status = 'partial';
        data.source_url = window.location.href;

        // Check if we have at least some data
        if (data.name || data.email || data.phone) {
            saveLead(data);
        }
    }, 1000);

    // Attach to all forms
    document.addEventListener('input', handleInput);

    // Track abandoned leads on page leave
    window.addEventListener('beforeunload', () => {
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            const formData = new FormData(form);
            const data = Object.fromEntries(formData.entries());
            if (data.name || data.email || data.phone) {
                // Use sendBeacon for reliable leave tracking
                const payload = JSON.stringify({
                    ...data,
                    status: 'abandoned',
                    source_url: window.location.href
                });
                navigator.sendBeacon('api/save_lead.php', payload);
            }
        });
    });

    // Exit Intent Popup
    let exitIntentShown = false;
    document.addEventListener('mouseleave', (e) => {
        if (e.clientY < 0 && !exitIntentShown) {
            exitIntentShown = true;
            showExitIntentPopup();
        }
    });

    function showExitIntentPopup() {
        const popup = document.createElement('div');
        popup.id = 'exit-intent-popup';
        popup.className = 'fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm px-6';
        popup.innerHTML = `
            <div class="bg-white rounded-[40px] p-12 max-w-lg w-full shadow-2xl relative">
                <button id="close-popup" class="absolute top-8 right-8 text-gray-400 hover:text-black transition">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </button>
                <h2 class="text-4xl font-serif mb-6">Wait! Before you go...</h2>
                <p class="text-gray-500 mb-8">Get exclusive access to our off-market luxury listings in Dubai and Mumbai.</p>
                <form id="exit-form" class="space-y-6">
                    <input type="hidden" name="status" value="submitted">
                    <input type="text" name="name" placeholder="Full Name" class="w-full bg-gray-50 border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-black outline-none transition">
                    <input type="email" name="email" placeholder="Email Address" class="w-full bg-gray-50 border-none rounded-2xl px-6 py-4 focus:ring-2 focus:ring-black outline-none transition">
                    <button type="submit" class="w-full bg-black text-white py-5 rounded-2xl font-bold hover:bg-gray-800 transition shadow-xl">Get Access</button>
                </form>
            </div>
        `;
        document.body.appendChild(popup);

        document.getElementById('close-popup').addEventListener('click', () => {
            popup.remove();
        });

        document.getElementById('exit-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const data = Object.fromEntries(formData.entries());
            data.status = 'submitted';
            data.source_url = window.location.href;
            
            await saveLead(data);
            popup.innerHTML = `
                <div class="bg-white rounded-[40px] p-12 max-w-lg w-full shadow-2xl text-center">
                    <h2 class="text-4xl font-serif mb-6">Thank You!</h2>
                    <p class="text-gray-500">We've sent the exclusive listings to your email.</p>
                    <button onclick="document.getElementById('exit-intent-popup').remove()" class="mt-8 bg-black text-white px-10 py-4 rounded-full font-bold hover:bg-gray-800 transition">Close</button>
                </div>
            `;
        });
    }
})();
