<?php
/**
 * CRM Lead Detail - Pillars to Home
 */
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireLogin();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$stmt = $pdo->prepare("SELECT * FROM leads WHERE id = ?");
$stmt->execute([$id]);
$lead = $stmt->fetch();

if (!$lead) {
    header('Location: leads.php');
    exit;
}

// Handle Note Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['note'])) {
    $note = sanitize($_POST['note']);
    $stmt = $pdo->prepare("INSERT INTO lead_notes (lead_id, user_id, note) VALUES (?, ?, ?)");
    $stmt->execute([$id, $_SESSION['user_id'], $note]);
    header("Location: lead_detail.php?id=$id&success=note_added");
    exit;
}

// Handle Status Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status'])) {
    $status = sanitize($_POST['status']);
    $stmt = $pdo->prepare("UPDATE leads SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);
    
    // Log event
    $stmt = $pdo->prepare("INSERT INTO lead_events (lead_id, event_type, event_data) VALUES (?, 'status_change', ?)");
    $stmt->execute([$id, "Status changed to: $status"]);
    
    header("Location: lead_detail.php?id=$id&success=status_updated");
    exit;
}

// Fetch Timeline
$stmt = $pdo->prepare("SELECT * FROM lead_events WHERE lead_id = ? ORDER BY created_at DESC");
$stmt->execute([$id]);
$events = $stmt->fetchAll();

// Fetch Activity Logs
$stmt = $pdo->prepare("SELECT * FROM activity_logs WHERE session_id = ? ORDER BY created_at DESC");
$stmt->execute([$lead['session_id']]);
$activity = $stmt->fetchAll();

// Fetch Notes
$stmt = $pdo->prepare("SELECT n.*, a.full_name FROM lead_notes n JOIN admins a ON n.user_id = a.id WHERE n.lead_id = ? ORDER BY n.created_at DESC");
$stmt->execute([$id]);
$notes = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lead Detail | Pillars to Home CRM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3 { font-family: 'DM Serif Display', serif; }
    </style>
</head>
<body class="bg-gray-50 text-gray-900 flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-72 bg-white border-r border-gray-100 flex flex-col p-8 fixed h-full">
        <div class="mb-12">
            <h1 class="text-2xl font-bold tracking-tighter">CRM DASHBOARD</h1>
            <p class="text-gray-400 text-[10px] uppercase tracking-widest font-bold mt-2">Pillars to Home</p>
        </div>
        
        <nav class="flex-1 space-y-4">
            <a href="dashboard.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                Dashboard
            </a>
            <a href="leads.php" class="flex items-center gap-4 text-black font-bold p-4 bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                Leads Management
            </a>
        </nav>
        
        <div class="mt-auto pt-8 border-t border-gray-100">
            <a href="logout.php" class="text-xs font-bold text-red-500 uppercase tracking-widest hover:text-red-700 transition">Logout</a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 ml-72 p-12">
        <header class="flex justify-between items-end mb-12">
            <div>
                <a href="leads.php" class="text-xs font-bold uppercase tracking-widest text-gray-400 hover:text-black transition flex items-center gap-2 mb-4">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
                    Back to Leads
                </a>
                <h2 class="text-4xl mb-2"><?= $lead['name'] ?: 'Anonymous Lead' ?></h2>
                <p class="text-gray-400">Lead ID: #<?= $lead['id'] ?> | Session: <?= $lead['session_id'] ?></p>
            </div>
            <div class="flex gap-4">
                <form method="POST" class="flex gap-4">
                    <select name="status" class="bg-white border-none rounded-2xl px-6 py-3 shadow-sm focus:ring-2 focus:ring-black outline-none transition text-sm font-bold">
                        <option value="partial" <?= $lead['status'] === 'partial' ? 'selected' : '' ?>>Partial</option>
                        <option value="abandoned" <?= $lead['status'] === 'abandoned' ? 'selected' : '' ?>>Abandoned</option>
                        <option value="submitted" <?= $lead['status'] === 'submitted' ? 'selected' : '' ?>>Submitted</option>
                        <option value="contacted" <?= $lead['status'] === 'contacted' ? 'selected' : '' ?>>Contacted</option>
                        <option value="visit_scheduled" <?= $lead['status'] === 'visit_scheduled' ? 'selected' : '' ?>>Visit Scheduled</option>
                        <option value="negotiation" <?= $lead['status'] === 'negotiation' ? 'selected' : '' ?>>Negotiation</option>
                        <option value="closed" <?= $lead['status'] === 'closed' ? 'selected' : '' ?>>Closed</option>
                    </select>
                    <button type="submit" class="bg-black text-white px-8 py-3 rounded-2xl font-bold hover:bg-gray-800 transition shadow-lg">Update Status</button>
                </form>
            </div>
        </header>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <!-- Left: Lead Info & Notes -->
            <div class="lg:col-span-2 space-y-12">
                <!-- Info Card -->
                <div class="bg-white rounded-[40px] shadow-sm border border-gray-100 p-10 grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div>
                        <h3 class="text-xl font-bold uppercase tracking-widest text-xs text-gray-400 mb-6">Contact Information</h3>
                        <div class="space-y-4">
                            <div>
                                <p class="text-xs text-gray-400 uppercase tracking-widest font-bold">Email</p>
                                <p class="text-lg font-medium"><?= $lead['email'] ?: 'Not provided' ?></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-400 uppercase tracking-widest font-bold">Phone</p>
                                <p class="text-lg font-medium"><?= $lead['phone'] ?: 'Not provided' ?></p>
                            </div>
                            <div>
                                <p class="text-xs text-gray-400 uppercase tracking-widest font-bold">Source URL</p>
                                <p class="text-sm text-blue-500 truncate" title="<?= $lead['source_url'] ?>"><?= $lead['source_url'] ?></p>
                            </div>
                        </div>
                    </div>
                    <div>
                        <h3 class="text-xl font-bold uppercase tracking-widest text-xs text-gray-400 mb-6">Lead Intelligence</h3>
                        <div class="space-y-4">
                            <div class="flex justify-between items-center">
                                <p class="text-xs text-gray-400 uppercase tracking-widest font-bold">Intent Level</p>
                                <span class="text-sm font-bold <?= $lead['intent_level'] === 'high' ? 'text-orange-500' : 'text-gray-400' ?>"><?= strtoupper($lead['intent_level']) ?></span>
                            </div>
                            <div class="flex justify-between items-center">
                                <p class="text-xs text-gray-400 uppercase tracking-widest font-bold">Lead Score</p>
                                <span class="text-sm font-bold"><?= $lead['score'] ?> Points</span>
                            </div>
                            <div class="flex justify-between items-center">
                                <p class="text-xs text-gray-400 uppercase tracking-widest font-bold">Hot Lead</p>
                                <span class="w-3 h-3 rounded-full <?= $lead['is_hot'] ? 'bg-red-500 animate-pulse' : 'bg-gray-200' ?>"></span>
                            </div>
                            <div class="pt-4 border-t border-gray-50">
                                <p class="text-xs text-gray-400 uppercase tracking-widest font-bold mb-2">UTM Source</p>
                                <p class="text-sm font-bold"><?= $lead['utm_source'] ?: 'Direct' ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Notes Section -->
                <div class="bg-white rounded-[40px] shadow-sm border border-gray-100 p-10">
                    <h3 class="text-2xl mb-8">Follow-up Notes</h3>
                    <form method="POST" class="mb-10">
                        <textarea name="note" required rows="4" class="w-full bg-gray-50 border-none rounded-3xl px-6 py-4 focus:ring-2 focus:ring-black outline-none transition mb-4" placeholder="Add a note about this lead..."></textarea>
                        <button type="submit" class="bg-black text-white px-10 py-4 rounded-full font-bold hover:bg-gray-800 transition shadow-lg">Add Note</button>
                    </form>

                    <div class="space-y-8">
                        <?php foreach ($notes as $note): ?>
                        <div class="flex gap-6">
                            <div class="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center font-bold text-xs">
                                <?= strtoupper(substr($note['full_name'], 0, 1)) ?>
                            </div>
                            <div class="flex-1">
                                <div class="flex justify-between items-center mb-2">
                                    <p class="text-sm font-bold"><?= $note['full_name'] ?></p>
                                    <p class="text-[10px] text-gray-400 uppercase tracking-widest font-bold"><?= date('M d, Y H:i', strtotime($note['created_at'])) ?></p>
                                </div>
                                <p class="text-gray-600 text-sm leading-relaxed"><?= nl2br($note['note']) ?></p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Activity Logs -->
                <div class="bg-white rounded-[40px] shadow-sm border border-gray-100 p-10">
                    <h3 class="text-2xl mb-8">User Behavior Log</h3>
                    <div class="space-y-6">
                        <?php foreach ($activity as $act): ?>
                        <div class="flex justify-between items-center text-sm">
                            <div class="flex items-center gap-4">
                                <span class="w-2 h-2 rounded-full bg-gray-200"></span>
                                <p class="text-gray-500">
                                    <span class="font-bold text-black uppercase text-[10px] tracking-widest"><?= $act['event_type'] ?></span>
                                    on <?= basename($act['page_url']) ?: 'Home' ?>
                                    <?php if ($act['event_value']): ?>
                                    - <span class="italic">"<?= $act['event_value'] ?>"</span>
                                    <?php endif; ?>
                                </p>
                            </div>
                            <p class="text-[10px] text-gray-400 uppercase tracking-widest font-bold"><?= date('H:i:s', strtotime($act['created_at'])) ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Right: Timeline -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-[40px] shadow-sm border border-gray-100 p-10">
                    <h3 class="text-2xl mb-8">Lead Timeline</h3>
                    <div class="relative space-y-12 before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-gray-100">
                        <?php foreach ($events as $event): ?>
                        <div class="relative pl-10">
                            <div class="absolute left-0 top-1 w-6 h-6 rounded-full bg-white border-4 border-black z-10"></div>
                            <p class="text-[10px] text-gray-400 uppercase tracking-widest font-bold mb-1"><?= date('M d, H:i', strtotime($event['created_at'])) ?></p>
                            <p class="text-sm font-bold mb-1"><?= strtoupper($event['event_type']) ?></p>
                            <p class="text-xs text-gray-500"><?= $event['event_data'] ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
