<?php
/**
 * CRM Leads Management - Pillars to Home
 */
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireLogin();

// Filters
$status_filter = isset($_GET['status']) ? sanitize($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';

$query = "SELECT * FROM leads WHERE 1=1";
$params = [];

if ($status_filter) {
    $query .= " AND status = ?";
    $params[] = $status_filter;
}

if ($search) {
    $query .= " AND (name LIKE ? OR email LIKE ? OR phone LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

$query .= " ORDER BY created_at DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$leads = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leads Management | Pillars to Home CRM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3 { font-family: 'DM Serif Display', serif; }
    </style>
</head>
<body class="bg-gray-50 text-gray-900 flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-72 bg-white border-r border-gray-100 flex flex-col p-8 fixed h-full">
        <div class="mb-12">
            <h1 class="text-2xl font-bold tracking-tighter">CRM DASHBOARD</h1>
            <p class="text-gray-400 text-[10px] uppercase tracking-widest font-bold mt-2">Pillars to Home</p>
        </div>
        
        <nav class="flex-1 space-y-4">
            <a href="dashboard.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                Dashboard
            </a>
            <a href="leads.php" class="flex items-center gap-4 text-black font-bold p-4 bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                Leads Management
            </a>
            <a href="properties.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                Properties
            </a>
            <a href="analytics.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                Analytics
            </a>
        </nav>
        
        <div class="mt-auto pt-8 border-t border-gray-100">
            <a href="logout.php" class="text-xs font-bold text-red-500 uppercase tracking-widest hover:text-red-700 transition">Logout</a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 ml-72 p-12">
        <header class="flex justify-between items-end mb-12">
            <div>
                <h2 class="text-4xl mb-2">Leads Management</h2>
                <p class="text-gray-400">Manage and track all incoming luxury real estate inquiries.</p>
            </div>
            <div class="flex gap-4">
                <form method="GET" class="flex gap-4">
                    <input type="text" name="search" value="<?= $search ?>" placeholder="Search name, email..." class="bg-white border-none rounded-2xl px-6 py-3 shadow-sm focus:ring-2 focus:ring-black outline-none transition text-sm">
                    <select name="status" class="bg-white border-none rounded-2xl px-6 py-3 shadow-sm focus:ring-2 focus:ring-black outline-none transition text-sm">
                        <option value="">All Status</option>
                        <option value="partial" <?= $status_filter === 'partial' ? 'selected' : '' ?>>Partial</option>
                        <option value="abandoned" <?= $status_filter === 'abandoned' ? 'selected' : '' ?>>Abandoned</option>
                        <option value="submitted" <?= $status_filter === 'submitted' ? 'selected' : '' ?>>Submitted</option>
                        <option value="contacted" <?= $status_filter === 'contacted' ? 'selected' : '' ?>>Contacted</option>
                    </select>
                    <button type="submit" class="bg-black text-white px-8 py-3 rounded-2xl font-bold hover:bg-gray-800 transition shadow-lg">Filter</button>
                </form>
            </div>
        </header>

        <!-- Leads Table -->
        <div class="bg-white rounded-[40px] shadow-sm border border-gray-100 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead>
                        <tr class="bg-gray-50 text-[10px] uppercase tracking-widest font-bold text-gray-400">
                            <th class="px-8 py-4">Lead Details</th>
                            <th class="px-8 py-4">Status</th>
                            <th class="px-8 py-4">Intent & Score</th>
                            <th class="px-8 py-4">Source</th>
                            <th class="px-8 py-4">Date</th>
                            <th class="px-8 py-4"></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-50">
                        <?php foreach ($leads as $lead): ?>
                        <tr class="hover:bg-gray-50 transition">
                            <td class="px-8 py-6">
                                <p class="font-bold text-sm"><?= $lead['name'] ?: 'Anonymous' ?></p>
                                <p class="text-xs text-gray-400"><?= $lead['email'] ?: $lead['phone'] ?: 'No contact info' ?></p>
                            </td>
                            <td class="px-8 py-6">
                                <span class="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest 
                                    <?= $lead['status'] === 'submitted' ? 'bg-green-50 text-green-600' : ($lead['status'] === 'abandoned' ? 'bg-red-50 text-red-600' : 'bg-gray-100 text-gray-500') ?>">
                                    <?= $lead['status'] ?>
                                </span>
                            </td>
                            <td class="px-8 py-6">
                                <div class="flex items-center gap-2">
                                    <span class="text-xs font-bold <?= $lead['intent_level'] === 'high' ? 'text-orange-500' : 'text-gray-400' ?>">
                                        <?= strtoupper($lead['intent_level']) ?>
                                    </span>
                                    <span class="text-[10px] bg-gray-50 px-2 py-1 rounded-lg font-bold text-gray-400"><?= $lead['score'] ?> pts</span>
                                    <?php if ($lead['is_hot']): ?>
                                    <span class="w-2 h-2 rounded-full bg-red-500 animate-pulse" title="Hot Lead"></span>
                                    <?php endif; ?>
                                </div>
                            </td>
                            <td class="px-8 py-6">
                                <p class="text-xs text-gray-400 truncate max-w-[150px]" title="<?= $lead['source_url'] ?>">
                                    <?= basename($lead['source_url']) ?: 'Home' ?>
                                </p>
                                <?php if ($lead['utm_source']): ?>
                                <p class="text-[10px] text-blue-400 font-bold uppercase tracking-widest"><?= $lead['utm_source'] ?></p>
                                <?php endif; ?>
                            </td>
                            <td class="px-8 py-6 text-xs text-gray-400">
                                <?= date('M d, Y H:i', strtotime($lead['created_at'])) ?>
                            </td>
                            <td class="px-8 py-6 text-right">
                                <a href="lead_detail.php?id=<?= $lead['id'] ?>" class="text-black hover:text-gray-500 transition">
                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
</body>
</html>
