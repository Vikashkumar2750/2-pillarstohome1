<?php
/**
 * CRM Dashboard - Pillars to Home
 */
require_once '../includes/auth.php';
require_once '../includes/functions.php';
requireLogin();

// Fetch Stats
$total_leads = $pdo->query("SELECT COUNT(*) FROM leads")->fetchColumn();
$abandoned_leads = $pdo->query("SELECT COUNT(*) FROM leads WHERE status = 'abandoned'")->fetchColumn();
$submitted_leads = $pdo->query("SELECT COUNT(*) FROM leads WHERE status = 'submitted'")->fetchColumn();
$hot_leads = $pdo->query("SELECT COUNT(*) FROM leads WHERE is_hot = 1")->fetchColumn();

// Conversion Rate
$conversion_rate = $total_leads > 0 ? round(($submitted_leads / $total_leads) * 100, 1) : 0;

// Top Visited Pages
$top_pages = $pdo->query("SELECT page_url, COUNT(*) as views FROM activity_logs WHERE event_type = 'view' GROUP BY page_url ORDER BY views DESC LIMIT 5")->fetchAll();

// Recent Activity
$recent_leads = $pdo->query("SELECT * FROM leads ORDER BY created_at DESC LIMIT 5")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Pillars to Home CRM</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
        h1, h2, h3 { font-family: 'DM Serif Display', serif; }
    </style>
</head>
<body class="bg-gray-50 text-gray-900 flex min-h-screen">
    <!-- Sidebar -->
    <aside class="w-72 bg-white border-r border-gray-100 flex flex-col p-8 fixed h-full">
        <div class="mb-12">
            <h1 class="text-2xl font-bold tracking-tighter">CRM DASHBOARD</h1>
            <p class="text-gray-400 text-[10px] uppercase tracking-widest font-bold mt-2">Pillars to Home</p>
        </div>
        
        <nav class="flex-1 space-y-4">
            <a href="dashboard.php" class="flex items-center gap-4 text-black font-bold p-4 bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>
                Dashboard
            </a>
            <a href="leads.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                Leads Management
            </a>
            <a href="properties.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>
                Properties
            </a>
            <a href="analytics.php" class="flex items-center gap-4 text-gray-400 hover:text-black p-4 hover:bg-gray-50 rounded-2xl transition">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>
                Analytics
            </a>
        </nav>
        
        <div class="mt-auto pt-8 border-t border-gray-100">
            <div class="flex items-center gap-4 mb-6">
                <div class="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center font-bold">
                    <?= strtoupper(substr($_SESSION['user_full_name'], 0, 1)) ?>
                </div>
                <div>
                    <p class="text-sm font-bold"><?= $_SESSION['user_full_name'] ?></p>
                    <p class="text-[10px] text-gray-400 uppercase tracking-widest"><?= $_SESSION['user_role'] ?></p>
                </div>
            </div>
            <a href="logout.php" class="text-xs font-bold text-red-500 uppercase tracking-widest hover:text-red-700 transition">Logout</a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="flex-1 ml-72 p-12">
        <header class="flex justify-between items-center mb-12">
            <div>
                <h2 class="text-4xl mb-2">Welcome back, <?= explode(' ', $_SESSION['user_full_name'])[0] ?></h2>
                <p class="text-gray-400">Here's what's happening with your luxury portfolio today.</p>
            </div>
            <div class="bg-white px-6 py-3 rounded-2xl shadow-sm border border-gray-100 text-sm font-medium">
                <?= date('F d, Y') ?>
            </div>
        </header>

        <!-- Stats Grid -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            <div class="bg-white p-8 rounded-[32px] shadow-sm border border-gray-100">
                <p class="text-[10px] uppercase tracking-widest font-bold text-gray-400 mb-4">Total Leads</p>
                <h3 class="text-4xl mb-2"><?= $total_leads ?></h3>
                <p class="text-xs text-green-500 font-bold">+12% from last week</p>
            </div>
            <div class="bg-white p-8 rounded-[32px] shadow-sm border border-gray-100">
                <p class="text-[10px] uppercase tracking-widest font-bold text-gray-400 mb-4">Abandoned</p>
                <h3 class="text-4xl mb-2"><?= $abandoned_leads ?></h3>
                <p class="text-xs text-red-500 font-bold"><?= round(($abandoned_leads / max(1, $total_leads)) * 100) ?>% of total</p>
            </div>
            <div class="bg-white p-8 rounded-[32px] shadow-sm border border-gray-100">
                <p class="text-[10px] uppercase tracking-widest font-bold text-gray-400 mb-4">Hot Leads</p>
                <h3 class="text-4xl mb-2 text-orange-500"><?= $hot_leads ?></h3>
                <p class="text-xs text-gray-400 font-medium">High intent detected</p>
            </div>
            <div class="bg-white p-8 rounded-[32px] shadow-sm border border-gray-100">
                <p class="text-[10px] uppercase tracking-widest font-bold text-gray-400 mb-4">Conversion</p>
                <h3 class="text-4xl mb-2"><?= $conversion_rate ?>%</h3>
                <p class="text-xs text-blue-500 font-bold">Optimized performance</p>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <!-- Recent Leads -->
            <div class="lg:col-span-2">
                <div class="bg-white rounded-[40px] shadow-sm border border-gray-100 overflow-hidden">
                    <div class="p-8 border-b border-gray-50 flex justify-between items-center">
                        <h3 class="text-2xl">Recent Leads</h3>
                        <a href="leads.php" class="text-xs font-bold uppercase tracking-widest text-gray-400 hover:text-black transition">View All</a>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead>
                                <tr class="bg-gray-50 text-[10px] uppercase tracking-widest font-bold text-gray-400">
                                    <th class="px-8 py-4">Lead</th>
                                    <th class="px-8 py-4">Status</th>
                                    <th class="px-8 py-4">Intent</th>
                                    <th class="px-8 py-4">Date</th>
                                    <th class="px-8 py-4"></th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-50">
                                <?php foreach ($recent_leads as $lead): ?>
                                <tr class="hover:bg-gray-50 transition">
                                    <td class="px-8 py-6">
                                        <p class="font-bold text-sm"><?= $lead['name'] ?: 'Anonymous' ?></p>
                                        <p class="text-xs text-gray-400"><?= $lead['email'] ?: $lead['phone'] ?: 'No contact info' ?></p>
                                    </td>
                                    <td class="px-8 py-6">
                                        <span class="px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest 
                                            <?= $lead['status'] === 'submitted' ? 'bg-green-50 text-green-600' : ($lead['status'] === 'abandoned' ? 'bg-red-50 text-red-600' : 'bg-gray-100 text-gray-500') ?>">
                                            <?= $lead['status'] ?>
                                        </span>
                                    </td>
                                    <td class="px-8 py-6">
                                        <span class="text-xs font-bold <?= $lead['intent_level'] === 'high' ? 'text-orange-500' : 'text-gray-400' ?>">
                                            <?= strtoupper($lead['intent_level']) ?>
                                        </span>
                                    </td>
                                    <td class="px-8 py-6 text-xs text-gray-400">
                                        <?= date('M d, H:i', strtotime($lead['created_at'])) ?>
                                    </td>
                                    <td class="px-8 py-6 text-right">
                                        <a href="lead_detail.php?id=<?= $lead['id'] ?>" class="text-black hover:text-gray-500 transition">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Top Pages -->
            <div class="lg:col-span-1">
                <div class="bg-white rounded-[40px] shadow-sm border border-gray-100 p-8">
                    <h3 class="text-2xl mb-8">Top Visited Pages</h3>
                    <div class="space-y-8">
                        <?php foreach ($top_pages as $page): ?>
                        <div class="flex justify-between items-center">
                            <div class="flex-1 mr-4 overflow-hidden">
                                <p class="text-sm font-bold truncate"><?= basename($page['page_url']) ?: 'Home' ?></p>
                                <p class="text-[10px] text-gray-400 truncate"><?= $page['page_url'] ?></p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-bold"><?= $page['views'] ?></p>
                                <p class="text-[10px] text-gray-400 uppercase tracking-widest font-bold">Views</p>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <div class="mt-12 pt-8 border-t border-gray-50">
                        <h4 class="text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">System Health</h4>
                        <div class="flex items-center gap-4 text-sm">
                            <div class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                            <span>Lead Capture API: Active</span>
                        </div>
                        <div class="flex items-center gap-4 text-sm mt-4">
                            <div class="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
                            <span>Tracking System: Active</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</body>
</html>
