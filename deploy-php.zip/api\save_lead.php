<?php
/**
 * API: Save Lead - Pillars to Home
 */
header('Content-Type: application/json');
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

if (!$input) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid input']);
    exit;
}

$session_id = session_id();
$name = isset($input['name']) ? sanitize($input['name']) : null;
$email = isset($input['email']) ? sanitize($input['email']) : null;
$phone = isset($input['phone']) ? sanitize($input['phone']) : null;
$status = isset($input['status']) ? sanitize($input['status']) : 'partial';
$source_url = isset($input['source_url']) ? sanitize($input['source_url']) : $_SERVER['HTTP_REFERER'];
$ip_address = $_SERVER['REMOTE_ADDR'];
$user_agent = $_SERVER['HTTP_USER_AGENT'];

// UTM Parameters
$utm_source = isset($input['utm_source']) ? sanitize($input['utm_source']) : null;
$utm_medium = isset($input['utm_medium']) ? sanitize($input['utm_medium']) : null;
$utm_campaign = isset($input['utm_campaign']) ? sanitize($input['utm_campaign']) : null;

try {
    // Check if lead already exists for this session
    $stmt = $pdo->prepare("SELECT id FROM leads WHERE session_id = ?");
    $stmt->execute([$session_id]);
    $lead = $stmt->fetch();

    if ($lead) {
        $lead_id = $lead['id'];
        // Update existing lead
        $stmt = $pdo->prepare("UPDATE leads SET 
            name = COALESCE(?, name), 
            email = COALESCE(?, email), 
            phone = COALESCE(?, phone), 
            status = ?, 
            updated_at = CURRENT_TIMESTAMP 
            WHERE id = ?");
        $stmt->execute([$name, $email, $phone, $status, $lead_id]);
        
        // Log event
        $stmt = $pdo->prepare("INSERT INTO lead_events (lead_id, event_type, event_data) VALUES (?, 'update', ?)");
        $stmt->execute([$lead_id, "Lead updated: $status"]);
    } else {
        // Create new lead
        $stmt = $pdo->prepare("INSERT INTO leads (session_id, name, email, phone, status, source_url, utm_source, utm_medium, utm_campaign, ip_address, user_agent) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$session_id, $name, $email, $phone, $status, $source_url, $utm_source, $utm_medium, $utm_campaign, $ip_address, $user_agent]);
        $lead_id = $pdo->lastInsertId();
        
        // Log event
        $stmt = $pdo->prepare("INSERT INTO lead_events (lead_id, event_type, event_data) VALUES (?, 'create', ?)");
        $stmt->execute([$lead_id, "Lead created: $status"]);
    }

    // Run automation logic
    runAutomation($lead_id);

    echo json_encode(['status' => 'success', 'lead_id' => $lead_id]);
} catch (PDOException $e) {
    logSystem('error', "API Save Lead Error: " . $e->getMessage());
    echo json_encode(['status' => 'error', 'message' => 'Database error']);
}
?>
