import React, { createContext, useContext, useState, useEffect } from 'react';

interface CurrencyContextType {
  currencySymbol: string;
  formatPrice: (priceStr: string) => string;
}

const CurrencyContext = createContext<CurrencyContextType>({
  currencySymbol: '₹',
  formatPrice: (priceStr: string) => priceStr,
});

export const CurrencyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currencySymbol, setCurrencySymbol] = useState('₹');

  useEffect(() => {
    const fetchCurrency = async () => {
      try {
        const response = await fetch('/api/content?page=global');
        if (response.ok) {
          const data = await response.json();
          const currencyItem = data.find((item: any) => item.section === 'settings' && item.key === 'currency_symbol');
          if (currencyItem) {
            setCurrencySymbol(currencyItem.value);
          }
        }
      } catch (err) {
        console.error('Failed to fetch global currency', err);
      }
    };
    fetchCurrency();
  }, []);

  const formatPrice = (priceStr: string) => {
    if (!priceStr) return '';
    // If it starts with a number, just prepend the symbol
    if (/^[0-9]/.test(priceStr)) {
      return `${currencySymbol}${priceStr}`;
    }
    // Otherwise, replace any existing currency symbol ($, £, ₹, €, etc.) with the global one
    return priceStr.replace(/^[^0-9]+/, currencySymbol);
  };

  return (
    <CurrencyContext.Provider value={{ currencySymbol, formatPrice }}>
      {children}
    </CurrencyContext.Provider>
  );
};

export const useCurrency = () => useContext(CurrencyContext);
