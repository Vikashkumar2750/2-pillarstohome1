import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { Home } from './pages/Home';
import { Listings } from './pages/Listings';
import { PropertyDetails } from './pages/PropertyDetails';
import { Contact } from './pages/Contact';
import { About } from './pages/About';
import { Investment } from './pages/Investment';
import { AdminDashboard } from './pages/AdminDashboard';
import { AdminLogin } from './pages/AdminLogin';
import DynamicPage from './pages/DynamicPage';
import Privacy from './pages/Privacy';
import Terms from './pages/Terms';
import { Chatbot } from './components/Chatbot';
import { ExitIntentPopup } from './components/ExitIntentPopup';
import { useTracking } from './hooks/useTracking';
import { useContent } from './hooks/useContent';
import { MapPin, Phone, Mail, X, Facebook, Instagram, Linkedin, Twitter } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// Scroll tracking component
const ScrollTracker = () => {
  const { trackEvent } = useTracking();
  const location = useLocation();

  useEffect(() => {
    let maxScroll = 0;
    const handleScroll = () => {
      const scrollPercent = Math.round((window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100);
      if (scrollPercent > maxScroll && scrollPercent % 25 === 0) { // Track every 25%
        maxScroll = scrollPercent;
        trackEvent('scroll_depth', location.pathname, { depth: scrollPercent });
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [location, trackEvent]);

  return null;
};

const ProtectedAdmin = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(!!localStorage.getItem('admin_token'));
  
  if (!isAuthenticated) {
    return <AdminLogin onLogin={() => setIsAuthenticated(true)} />;
  }
  
  return <AdminDashboard />;
};

const Navbar = () => {
  const { content } = useContent('global');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [hoveredItem, setHoveredItem] = useState<number | null>(null);
  const location = useLocation();

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  useEffect(() => {
    fetch('/api/navigation')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setMenuItems(data);
        } else {
          console.error("Failed to load navigation:", data);
          setMenuItems([]);
        }
      })
      .catch(err => {
        console.error("Failed to load navigation:", err);
        setMenuItems([]);
      });
  }, []);

  const mainMenuItems = Array.isArray(menuItems) ? menuItems.filter(item => !item.parent_id).sort((a, b) => a.order_index - b.order_index) : [];
  const headerStyle = content.theme_header_style || 'transparent';

  let navClass = "fixed top-0 w-full z-50 transition-all duration-300 ";
  let textColor = "text-white";
  let linkColor = "text-gray-300";
  let logoColor = "text-white";
  let btnClass = "bg-white text-black hover:bg-gold-500";

  if (headerStyle === 'solid_dark') {
    navClass += "bg-luxury-900 border-b border-white/5";
  } else if (headerStyle === 'solid_light') {
    navClass += "bg-white border-b border-gray-200";
    textColor = "text-black";
    linkColor = "text-gray-600";
    logoColor = "text-black";
    btnClass = "bg-black text-white hover:bg-gold-500";
  } else {
    navClass += "bg-luxury-900/80 backdrop-blur-md border-b border-white/5";
  }

  const renderCompanyName = (name: string) => {
    const defaultName = "PillarstoHome";
    const displayName = name || defaultName;
    
    // Split by "Home" to color it differently
    const parts = displayName.split(/(Home)/g);
    return (
      <>
        {parts.map((part, i) => 
          part === 'Home' ? <span key={i} className="text-gold-500">{part}</span> : part
        )}
      </>
    );
  };

  return (
    <nav className={navClass}>
      <div className="max-w-7xl mx-auto px-4 h-20 flex items-center justify-between">
        <Link to="/" className={`text-xl sm:text-2xl font-serif tracking-widest shrink-0 ${logoColor} flex items-center`}>
          {content.navbar_logo_image ? (
            <img src={content.navbar_logo_image} alt={content.navbar_company_name || "PillarstoHome"} className="h-10 w-auto object-contain" referrerPolicy="no-referrer" />
          ) : (
            renderCompanyName(content.navbar_company_name)
          )}
        </Link>
        
        <div className={`hidden md:flex gap-8 text-sm font-medium ${linkColor}`}>
          {mainMenuItems.length > 0 ? (
            mainMenuItems.map(item => (
              <div 
                key={item.id} 
                className="relative"
                onMouseEnter={() => setHoveredItem(item.id)}
                onMouseLeave={() => setHoveredItem(null)}
              >
                <Link to={item.url} className="hover:text-gold-500 transition-colors py-8 flex items-center gap-1">
                  {item.label}
                </Link>
                {menuItems.some(sub => sub.parent_id === item.id) && (
                  <div className={`absolute top-full left-0 pt-0 transition-all duration-300 ${hoveredItem === item.id ? 'opacity-100 visible translate-y-0' : 'opacity-0 invisible -translate-y-2'}`}>
                    <div className="bg-luxury-800 border border-white/10 rounded-xl p-4 min-w-[200px] shadow-2xl mt-2">
                      {menuItems.filter(sub => sub.parent_id === item.id).sort((a, b) => a.order_index - b.order_index).map(sub => (
                        <Link 
                          key={sub.id} 
                          to={sub.url} 
                          className="block py-2 text-gray-400 hover:text-gold-500 transition-colors"
                        >
                          {sub.label}
                        </Link>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))
          ) : (
            <>
              <Link to="/" className="hover:text-gold-500 transition-colors">Home</Link>
              <Link to="/listings" className="hover:text-gold-500 transition-colors">Properties</Link>
              <Link to="/investment" className="hover:text-gold-500 transition-colors">Investment</Link>
              <Link to="/about" className="hover:text-gold-500 transition-colors">About</Link>
              <Link to="/contact" className="hover:text-gold-500 transition-colors">Contact</Link>
            </>
          )}
        </div>

        <div className="flex items-center gap-2 sm:gap-4">
          <Link to="/contact" className={`hidden sm:block px-5 py-2 rounded-full text-sm font-medium transition-colors ${btnClass}`}>
            {content.navbar_cta_text || "Inquire"}
          </Link>
          
          <button 
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className={`md:hidden p-2 transition-colors hover:text-gold-500 ${textColor}`}
          >
            {isMenuOpen ? <X size={24} /> : <div className="space-y-1.5 w-6"><div className="h-0.5 bg-current w-full" /><div className="h-0.5 bg-current w-full" /><div className="h-0.5 bg-current w-full" /></div>}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-luxury-800 border-b border-white/5 overflow-hidden"
          >
            <div className="px-4 py-8 flex flex-col gap-6 text-center">
              {mainMenuItems.length > 0 ? (
                mainMenuItems.map(item => (
                  <Link key={item.id} to={item.url} className="text-lg font-serif text-white hover:text-gold-500">
                    {item.label}
                  </Link>
                ))
              ) : (
                <>
                  <Link to="/" className="text-lg font-serif text-white hover:text-gold-500">Home</Link>
                  <Link to="/listings" className="text-lg font-serif text-white hover:text-gold-500">Properties</Link>
                  <Link to="/investment" className="text-lg font-serif text-white hover:text-gold-500">Investment</Link>
                  <Link to="/about" className="text-lg font-serif text-white hover:text-gold-500">About</Link>
                  <Link to="/contact" className="text-lg font-serif text-white hover:text-gold-500">Contact</Link>
                </>
              )}
              <div className="pt-4 flex flex-col gap-4">
                <Link to="/contact" className="bg-gold-500 text-black py-4 rounded-xl font-bold uppercase tracking-widest text-xs">
                  {content.navbar_cta_text || "Inquire Now"}
                </Link>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Footer = () => {
  const { content } = useContent('global');
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const footerStyle = content.theme_footer_style || 'dark';

  useEffect(() => {
    fetch('/api/navigation')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setMenuItems(data);
        } else {
          console.error("Failed to load navigation:", data);
          setMenuItems([]);
        }
      })
      .catch(err => {
        console.error("Failed to load navigation:", err);
        setMenuItems([]);
      });
  }, []);

  const mainMenuItems = Array.isArray(menuItems) ? menuItems.filter(item => !item.parent_id).sort((a, b) => a.order_index - b.order_index) : [];

  let footerClass = "pt-20 pb-10 border-t ";
  let textColor = "text-gray-400";
  let headingColor = "text-white";
  let logoColor = "text-white";
  let inputClass = "bg-luxury-800 border-white/10 text-white focus:border-gold-500";
  let socialClass = "bg-luxury-800 text-gray-400 hover:bg-gold-500 hover:text-black border-white/5";
  let bottomBorder = "border-white/5";

  if (footerStyle === 'light') {
    footerClass += "bg-stone-50 border-gray-200";
    textColor = "text-gray-600";
    headingColor = "text-stone-900";
    logoColor = "text-stone-900";
    inputClass = "bg-white border-gray-300 text-stone-900 focus:border-gold-500";
    socialClass = "bg-white text-gray-400 hover:bg-gold-500 hover:text-white border-gray-200";
    bottomBorder = "border-gray-200";
  } else if (footerStyle === 'minimal') {
    footerClass += "bg-black border-white/5";
  } else {
    footerClass += "bg-luxury-900 border-white/5";
  }

  const renderCompanyName = (name: string) => {
    const defaultName = "PillarstoHome";
    const displayName = name || defaultName;
    
    // Split by "Home" to color it differently
    const parts = displayName.split(/(Home)/g);
    return (
      <>
        {parts.map((part, i) => 
          part === 'Home' ? <span key={i} className="text-gold-500">{part}</span> : part
        )}
      </>
    );
  };

  return (
    <footer className={footerClass}>
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <Link to="/" className={`text-2xl font-serif tracking-widest ${logoColor} flex items-center`}>
              {content.navbar_logo_image ? (
                <img src={content.navbar_logo_image} alt={content.navbar_company_name || "PillarstoHome"} className="h-10 w-auto object-contain" referrerPolicy="no-referrer" />
              ) : (
                renderCompanyName(content.navbar_company_name)
              )}
            </Link>
            <p className={`text-sm leading-relaxed ${textColor}`}>
              {content.footer_about_text || "PillarstoHome is a premier luxury real estate CRM and investment platform, dedicated to providing unparalleled service and exclusive opportunities to our elite clientele."}
            </p>
            <div className="flex gap-4">
              <a href={content.social_facebook || "#"} target="_blank" rel="noopener noreferrer" className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border ${socialClass}`}>
                <span className="sr-only">facebook</span>
                <Facebook size={18} />
              </a>
              <a href={content.social_instagram || "#"} target="_blank" rel="noopener noreferrer" className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border ${socialClass}`}>
                <span className="sr-only">instagram</span>
                <Instagram size={18} />
              </a>
              <a href={content.social_linkedin || "#"} target="_blank" rel="noopener noreferrer" className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border ${socialClass}`}>
                <span className="sr-only">linkedin</span>
                <Linkedin size={18} />
              </a>
              <a href={content.social_twitter || "#"} target="_blank" rel="noopener noreferrer" className={`w-10 h-10 rounded-full flex items-center justify-center transition-all border ${socialClass}`}>
                <span className="sr-only">twitter</span>
                <Twitter size={18} />
              </a>
            </div>
          </div>

          <div>
            <h4 className={`font-serif text-lg mb-6 ${headingColor}`}>Quick Links</h4>
            <ul className={`space-y-4 text-sm ${textColor}`}>
              {mainMenuItems.length > 0 ? (
                mainMenuItems.map(item => (
                  <li key={item.id}><Link to={item.url} className="hover:text-gold-500 transition-colors">{item.label}</Link></li>
                ))
              ) : (
                <>
                  <li><Link to="/" className="hover:text-gold-500 transition-colors">Home</Link></li>
                  <li><Link to="/listings" className="hover:text-gold-500 transition-colors">Properties</Link></li>
                  <li><Link to="/investment" className="hover:text-gold-500 transition-colors">Investment</Link></li>
                  <li><Link to="/about" className="hover:text-gold-500 transition-colors">About Us</Link></li>
                  <li><Link to="/contact" className="hover:text-gold-500 transition-colors">Contact</Link></li>
                </>
              )}
            </ul>
          </div>

          <div>
            <h4 className={`font-serif text-lg mb-6 ${headingColor}`}>Contact Us</h4>
            <ul className={`space-y-4 text-sm ${textColor}`}>
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-gold-500 shrink-0" />
                <span>{content.footer_address || "3039p Sector 57, Hong Kong Bazaar"}</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-gold-500 shrink-0" />
                <a href={`tel:${content.contact_phone || "+919911414220"}`} className="hover:text-gold-500 transition-colors">
                  {content.contact_phone || "+919911414220"}
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-gold-500 shrink-0" />
                <a href={`mailto:${content.contact_email || "Pillarstohome57@gmail.com"}`} className="hover:text-gold-500 transition-colors">
                  {content.contact_email || "Pillarstohome57@gmail.com"}
                </a>
              </li>
            </ul>
          </div>

          <div>
            <h4 className={`font-serif text-lg mb-6 ${headingColor}`}>Newsletter</h4>
            <p className={`text-sm mb-6 ${textColor}`}>Subscribe to receive exclusive luxury property insights.</p>
            <form className="space-y-3" onSubmit={(e) => e.preventDefault()}>
              <input 
                type="email" 
                placeholder="Your Email" 
                className={`w-full border rounded-xl px-4 py-3 text-sm outline-none transition-colors ${inputClass}`}
              />
              <button className="w-full py-3 bg-gold-500 text-black font-bold rounded-xl text-xs uppercase tracking-widest hover:bg-gold-400 transition-colors">
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className={`pt-10 border-t flex flex-col md:flex-row justify-between items-center gap-6 text-xs text-gray-500 ${bottomBorder}`}>
          <p>&copy; 2026 {content.footer_company_name || "PillarstoHome Real Estate"}. All rights reserved.</p>
          <div className="flex gap-8">
            <Link to="/privacy" className="hover:text-gold-500 transition-colors">Privacy Policy</Link>
            <Link to="/terms" className="hover:text-gold-500 transition-colors">Terms of Service</Link>
            <a href="/sitemap.xml" className="hover:text-gold-500 transition-colors">Sitemap</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

const MainLayout = () => {
  const location = useLocation();
  const [pageSettings, setPageSettings] = useState<any>(null);

  useEffect(() => {
    const fetchPageSettings = async () => {
      const path = location.pathname;
      const slug = path === '/' ? 'home' : path.split('/').filter(Boolean)[0];
      
      // Skip for admin routes
      if (path.startsWith('/p2hadmin')) return;

      try {
        const res = await fetch(`/api/pages/${slug}`);
        if (res.ok) {
          const data = await res.json();
          setPageSettings(data);
        } else {
          // Default to showing if page not found in DB (might be a hardcoded route)
          setPageSettings({ show_header: 1, show_footer: 1 });
        }
      } catch (error) {
        setPageSettings({ show_header: 1, show_footer: 1 });
      }
    };

    fetchPageSettings();
  }, [location.pathname]);

  const showHeader = pageSettings?.show_header !== 0;
  const showFooter = pageSettings?.show_footer !== 0;

  return (
    <>
      {showHeader && <Navbar />}
      <div className={showHeader ? "pt-20" : ""}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/listings" element={<Listings />} />
          <Route path="/property/:id" element={<PropertyDetails />} />
          <Route path="/about" element={<About />} />
          <Route path="/investment" element={<Investment />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/:slug" element={<DynamicPage />} />
          <Route path="*" element={<div className="min-h-screen flex items-center justify-center text-gray-500">Page under construction</div>} />
        </Routes>
      </div>
      <Chatbot />
      <ExitIntentPopup />
      {showFooter && <Footer />}
    </>
  );
};

export default function App() {
  return (
    <Router>
      <ScrollTracker />
      <Routes>
        <Route path="/p2hadmin" element={<ProtectedAdmin />} />
        <Route path="*" element={<MainLayout />} />
      </Routes>
    </Router>
  );
}
