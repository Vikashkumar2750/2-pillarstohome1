import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTracking } from '../hooks/useTracking';
import { useContent } from '../hooks/useContent';
import { useCurrency } from '../contexts/CurrencyContext';
import { MapPin, Filter, Search, Scale, X, Check, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Listings = () => {
  const { trackEvent, sessionId } = useTracking();
  const { content } = useContent('listings');
  const { formatPrice } = useCurrency();
  const [properties, setProperties] = useState<any[]>([]);
  const [recommendations, setRecommendations] = useState<any[]>([]);
  const [filter, setFilter] = useState('All');
  const [searchTerm, setSearchTerm] = useState('');
  const [compareList, setCompareList] = useState<any[]>([]);
  const [showCompare, setShowCompare] = useState(false);

  const toggleCompare = (prop: any) => {
    if (compareList.find(p => p.id === prop.id)) {
      setCompareList(compareList.filter(p => p.id !== prop.id));
    } else if (compareList.length < 3) {
      setCompareList([...compareList, prop]);
    }
  };

  useEffect(() => {
    trackEvent('page_view', 'Listings');
    fetch('/api/properties')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setProperties(data);
        } else {
          console.error("API /api/properties did not return an array:", data);
          setProperties([]);
        }
      })
      .catch(error => {
        console.error("Error fetching properties:", error);
        setProperties([]);
      });
    
    // Fetch recommendations
    fetch(`/api/recommendations?sessionId=${sessionId}`)
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setRecommendations(data);
        } else {
          console.error("API /api/recommendations did not return an array:", data);
          setRecommendations([]);
        }
      })
      .catch(error => {
        console.error("Error fetching recommendations:", error);
        setRecommendations([]);
      });
  }, [trackEvent, sessionId]);

  const filtered = properties.filter(p => {
    const matchesType = filter === 'All' || p.type === filter;
    const matchesSearch = p.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          p.location.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesType && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-luxury-900 pt-10 pb-24 px-4 max-w-7xl mx-auto">
      <div className="mb-12">
        <h1 className="text-4xl md:text-5xl font-serif mb-4">{content.hero_title || "Exclusive Properties"}</h1>
        <p className="text-gray-400 max-w-2xl">{content.hero_subtitle || "Explore our curated collection of the world's finest real estate."}</p>
      </div>

      {recommendations.length > 0 && (
        <div className="mb-16">
          <div className="flex items-center gap-2 mb-6">
            <span className="w-1.5 h-1.5 rounded-full bg-gold-500"></span>
            <h2 className="text-xl font-serif">{content.recommendations_title || "Recommended for you"}</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {recommendations.map((prop, i) => (
              <Link to={`/property/${prop.id}`} key={`rec-${prop.id}`}>
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: i * 0.1 }}
                  className="group cursor-pointer bg-luxury-800/50 rounded-xl overflow-hidden border border-white/5 hover:border-gold-500/30 transition-all"
                >
                  <div className="relative h-40 overflow-hidden">
                    <img 
                      src={prop.image} 
                      alt={prop.title} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80";
                      }}
                    />
                  </div>
                  <div className="p-4">
                    <h3 className="text-sm font-serif mb-1 group-hover:text-gold-500 transition-colors truncate">{prop.title}</h3>
                    <div className="flex justify-between items-center mt-2">
                      <span className="text-sm font-medium text-gold-500">{formatPrice(prop.price)}</span>
                      <span className="text-[10px] text-gray-500 uppercase tracking-wider">{prop.type}</span>
                    </div>
                  </div>
                </motion.div>
              </Link>
            ))}
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row justify-between items-center mb-10 gap-4">
        <div className="flex gap-2 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
          {['All', 'Penthouse', 'Villa', 'Apartment'].map(type => (
            <button 
              key={type}
              onClick={() => setFilter(type)}
              className={`px-6 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${filter === type ? 'bg-gold-500 text-black' : 'bg-luxury-800 text-gray-300 hover:bg-luxury-700'}`}
            >
              {type}
            </button>
          ))}
        </div>
        <div className="relative w-full md:w-64">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={16} />
          <input 
            type="text" 
            placeholder="Search location or title..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-luxury-800 border border-white/10 rounded-full pl-10 pr-4 py-2 text-sm text-white focus:outline-none focus:border-gold-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filtered.map((prop, i) => (
          <Link to={`/property/${prop.id}`} key={prop.id}>
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="group cursor-pointer bg-luxury-800 rounded-2xl overflow-hidden border border-white/5 hover:border-white/10 transition-colors"
            >
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={prop.image} 
                  alt={prop.title} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80";
                  }}
                />
                <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-md px-3 py-1 rounded-full text-xs font-medium border border-white/10">
                  {prop.type}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-serif mb-2 group-hover:text-gold-500 transition-colors">{prop.title}</h3>
                <div className="flex items-center gap-2 text-gray-400 text-sm mb-4">
                  <MapPin size={14} /> {prop.location}
                </div>
                <div className="flex justify-between items-center pt-4 border-t border-white/5">
                  <span className="text-xl font-medium text-white">{formatPrice(prop.price)}</span>
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                        toggleCompare(prop);
                      }}
                      className={`p-2 rounded-full border transition-all ${compareList.find(p => p.id === prop.id) ? 'bg-gold-500 border-gold-500 text-black' : 'border-white/10 text-gray-400 hover:border-gold-500 hover:text-gold-500'}`}
                      title="Compare Property"
                    >
                      <Scale size={16} />
                    </button>
                    <div className="flex gap-3 text-xs text-gray-400 font-medium">
                      <span className="bg-luxury-900 px-2 py-1 rounded">{prop.beds}B</span>
                      <span className="bg-luxury-900 px-2 py-1 rounded">{prop.baths}Ba</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </Link>
        ))}
      </div>

      {/* Comparison Drawer */}
      <AnimatePresence>
        {compareList.length > 0 && (
          <motion.div 
            initial={{ y: 100 }}
            animate={{ y: 0 }}
            exit={{ y: 100 }}
            className="fixed bottom-0 left-0 right-0 bg-luxury-800 border-t border-white/10 p-4 z-40 shadow-2xl"
          >
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-6">
                <div className="hidden md:block">
                  <p className="text-white font-serif">Comparison Tool</p>
                  <p className="text-xs text-gray-500">{compareList.length} of 3 selected</p>
                </div>
                <div className="flex gap-3">
                  {compareList.map(prop => (
                    <div key={`comp-${prop.id}`} className="relative group">
                      <img src={prop.image} alt="" className="w-12 h-12 rounded-lg object-cover border border-white/10" referrerPolicy="no-referrer" />
                      <button 
                        onClick={() => toggleCompare(prop)}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X size={10} />
                      </button>
                    </div>
                  ))}
                  {[...Array(3 - compareList.length)].map((_, i) => (
                    <div key={`empty-${i}`} className="w-12 h-12 rounded-lg border border-dashed border-white/10 flex items-center justify-center text-gray-600">
                      <Plus size={14} />
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex gap-4">
                <button 
                  onClick={() => setCompareList([])}
                  className="text-gray-400 text-sm hover:text-white transition-colors"
                >
                  Clear All
                </button>
                <button 
                  disabled={compareList.length < 2}
                  onClick={() => setShowCompare(true)}
                  className="bg-gold-500 text-black px-6 py-2 rounded-full text-sm font-medium hover:bg-gold-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Compare Now
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Comparison Modal */}
      <AnimatePresence>
        {showCompare && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 backdrop-blur-xl z-50 flex items-center justify-center p-4"
          >
            <div className="bg-luxury-800 border border-white/10 rounded-3xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col">
              <div className="p-6 border-b border-white/10 flex justify-between items-center">
                <h2 className="text-2xl font-serif text-white">Property Comparison</h2>
                <button onClick={() => setShowCompare(false)} className="text-gray-400 hover:text-white transition-colors">
                  <X size={24} />
                </button>
              </div>
              <div className="flex-1 overflow-auto p-8">
                <div className="grid grid-cols-4 gap-8">
                  <div className="space-y-12 pt-48">
                    <div className="text-gray-500 text-sm font-medium uppercase tracking-widest border-b border-white/5 pb-2">Price</div>
                    <div className="text-gray-500 text-sm font-medium uppercase tracking-widest border-b border-white/5 pb-2">Location</div>
                    <div className="text-gray-500 text-sm font-medium uppercase tracking-widest border-b border-white/5 pb-2">Type</div>
                    <div className="text-gray-500 text-sm font-medium uppercase tracking-widest border-b border-white/5 pb-2">Bedrooms</div>
                    <div className="text-gray-500 text-sm font-medium uppercase tracking-widest border-b border-white/5 pb-2">Bathrooms</div>
                    <div className="text-gray-500 text-sm font-medium uppercase tracking-widest border-b border-white/5 pb-2">Area</div>
                  </div>
                  {compareList.map(prop => (
                    <div key={`modal-comp-${prop.id}`} className="space-y-12 text-center">
                      <div className="h-40 mb-8">
                        <img src={prop.image} alt="" className="w-full h-full object-cover rounded-2xl border border-white/10" referrerPolicy="no-referrer" />
                        <h3 className="mt-4 font-serif text-lg truncate">{prop.title}</h3>
                      </div>
                      <div className="text-gold-500 font-medium border-b border-white/5 pb-2">{formatPrice(prop.price)}</div>
                      <div className="text-gray-300 border-b border-white/5 pb-2 truncate">{prop.location}</div>
                      <div className="text-gray-300 border-b border-white/5 pb-2">{prop.type}</div>
                      <div className="text-gray-300 border-b border-white/5 pb-2">{prop.beds}</div>
                      <div className="text-gray-300 border-b border-white/5 pb-2">{prop.baths}</div>
                      <div className="text-gray-300 border-b border-white/5 pb-2">{prop.sqft} sqft</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="p-6 border-t border-white/10 text-center">
                <button 
                  onClick={() => setShowCompare(false)}
                  className="bg-white text-black px-8 py-3 rounded-full font-medium hover:bg-gold-500 transition-colors"
                >
                  Close Comparison
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
