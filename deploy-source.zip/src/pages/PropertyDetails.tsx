import React, { useEffect, useState, useCallback } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useTracking } from '../hooks/useTracking';
import { useCurrency } from '../contexts/CurrencyContext';
import { LeadForm } from '../components/LeadForm';
import { MortgageCalculator } from '../components/MortgageCalculator';
import { MapPin, Bed, Bath, Square, Play, Check, Calendar, Sparkles, X, Clock, Info, Download, CheckCircle2, Loader2, Share2, Heart } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { GoogleGenAI } from "@google/genai";
import { VideoModal } from '../components/VideoModal';

import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

const TourModal = ({ isOpen, onClose, propertyTitle, submitFullLead }: { isOpen: boolean, onClose: () => void, propertyTitle: string, submitFullLead: any }) => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({ name: '', email: '', phone: '', date: '', time: '' });
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await submitFullLead({
        ...formData,
        type: 'Tour Request',
        property: propertyTitle,
        source: `Tour Schedule: ${propertyTitle}`
      });
      if (res.success) setSuccess(true);
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-luxury-800 border border-white/10 rounded-3xl p-8 max-w-md w-full relative overflow-hidden"
        >
          <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-white">
            <X size={24} />
          </button>

          {success ? (
            <div className="text-center py-8">
              <div className="w-16 h-16 bg-gold-500/20 text-gold-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <Check size={32} />
              </div>
              <h3 className="text-2xl font-serif text-white mb-2">Tour Requested!</h3>
              <p className="text-gray-400 mb-8">One of our luxury consultants will contact you shortly to confirm your visit.</p>
              <button onClick={onClose} className="w-full py-4 bg-gold-500 text-black font-medium rounded-xl hover:bg-gold-400 transition-colors">
                Close
              </button>
            </div>
          ) : (
            <>
              <h3 className="text-2xl font-serif text-white mb-2">Schedule a Private Tour</h3>
              <p className="text-gray-400 mb-8">Experience {propertyTitle} in person.</p>

              <form onSubmit={handleSubmit} className="space-y-4">
                {step === 1 ? (
                  <>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-xs uppercase tracking-widest text-gray-500">Date</label>
                        <input 
                          type="date" 
                          required
                          className="w-full bg-luxury-900 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-gold-500 outline-none transition-colors"
                          value={formData.date}
                          onChange={e => setFormData({...formData, date: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs uppercase tracking-widest text-gray-500">Time</label>
                        <select 
                          required
                          className="w-full bg-luxury-900 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-gold-500 outline-none transition-colors"
                          value={formData.time}
                          onChange={e => setFormData({...formData, time: e.target.value})}
                        >
                          <option value="">Select Time</option>
                          <option value="10:00 AM">10:00 AM</option>
                          <option value="11:30 AM">11:30 AM</option>
                          <option value="01:00 PM">01:00 PM</option>
                          <option value="02:30 PM">02:30 PM</option>
                          <option value="04:00 PM">04:00 PM</option>
                        </select>
                      </div>
                    </div>
                    <button 
                      type="button"
                      onClick={() => setStep(2)}
                      disabled={!formData.date || !formData.time}
                      className="w-full py-4 bg-gold-500 text-black font-medium rounded-xl hover:bg-gold-400 transition-colors disabled:opacity-50"
                    >
                      Next Step
                    </button>
                  </>
                ) : (
                  <>
                    <div className="space-y-2">
                      <label className="text-xs uppercase tracking-widest text-gray-500">Your Name</label>
                      <input 
                        type="text" 
                        required
                        placeholder="John Doe"
                        className="w-full bg-luxury-900 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-gold-500 outline-none transition-colors"
                        value={formData.name}
                        onChange={e => setFormData({...formData, name: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-xs uppercase tracking-widest text-gray-500">Email Address</label>
                      <input 
                        type="email" 
                        required
                        placeholder="john@example.com"
                        className="w-full bg-luxury-900 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-gold-500 outline-none transition-colors"
                        value={formData.email}
                        onChange={e => setFormData({...formData, email: e.target.value})}
                      />
                    </div>
                    <div className="flex gap-4">
                      <button 
                        type="button"
                        onClick={() => setStep(1)}
                        className="flex-1 py-4 border border-white/10 text-white font-medium rounded-xl hover:bg-white/5 transition-colors"
                      >
                        Back
                      </button>
                      <button 
                        type="submit"
                        disabled={submitting}
                        className="flex-[2] py-4 bg-gold-500 text-black font-medium rounded-xl hover:bg-gold-400 transition-colors disabled:opacity-50"
                      >
                        {submitting ? 'Requesting...' : 'Confirm Request'}
                      </button>
                    </div>
                  </>
                )}
              </form>
            </>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export const PropertyDetails = () => {
  const { id } = useParams();
  const { trackEvent, submitFullLead } = useTracking();
  const { formatPrice, currencySymbol } = useCurrency();
  const [property, setProperty] = useState<any>(null);
  const [insights, setInsights] = useState<string | null>(null);
  const [loadingInsights, setLoadingInsights] = useState(false);
  const [showTourModal, setShowTourModal] = useState(false);
  const [showVideo, setShowVideo] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);

  useEffect(() => {
    if (id) {
      trackEvent('page_view', `Property Details - ${id}`);
      fetch(`/api/properties/${id}`)
        .then(res => res.json())
        .then(data => setProperty(data));
    }
  }, [id, trackEvent]);

  const simulateDownload = () => {
    setIsDownloading(true);
    setDownloadProgress(0);
    const interval = setInterval(() => {
      setDownloadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => setIsDownloading(false), 1000);
          return 100;
        }
        return prev + 5;
      });
    }, 100);
  };

  const fetchInsights = useCallback(async () => {
    if (!property || insights) return;
    setLoadingInsights(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Provide luxury neighborhood insights for a property in ${property.location}. Focus on lifestyle, investment potential, and nearby elite amenities. Keep it professional and concise (max 150 words).`,
        config: {
          tools: [{ googleSearch: {} }]
        }
      });
      setInsights(response.text);
    } catch (err) {
      console.error(err);
      setInsights("Unable to load neighborhood insights at this time.");
    } finally {
      setLoadingInsights(false);
    }
  }, [property, insights]);

  if (!property) return <div className="min-h-screen flex items-center justify-center text-white">Loading...</div>;

  return (
    <div className="min-h-screen bg-luxury-900 pb-24">
      <VideoModal 
        isOpen={showVideo} 
        onClose={() => setShowVideo(false)} 
        videoUrl={property.video_url || "https://www.youtube.com/watch?v=0k_v9E_7v6c"} 
        title={`Cinematic Tour: ${property.title}`}
      />

      <TourModal 
        isOpen={showTourModal} 
        onClose={() => setShowTourModal(false)} 
        propertyTitle={property.title} 
        submitFullLead={submitFullLead}
      />

      {/* Hero Image */}
      <div className="relative h-[50vh] sm:h-[60vh] md:h-[70vh] w-full overflow-hidden">
        <motion.img 
          initial={{ scale: 1.1 }}
          animate={{ scale: 1 }}
          transition={{ duration: 1.5 }}
          src={property.image} 
          alt={property.title} 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80";
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-luxury-900 via-luxury-900/20 to-transparent"></div>
        <div className="absolute bottom-0 left-0 w-full p-6 sm:p-8 md:p-16 max-w-7xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-4"
          >
            <div className="inline-flex items-center gap-2 bg-gold-500 text-black px-4 py-1 rounded-full text-xs sm:text-sm font-bold tracking-widest uppercase">
              <Sparkles size={14} /> {property.type}
            </div>
            <h1 className="text-3xl sm:text-5xl md:text-7xl font-serif text-white leading-tight">{property.title}</h1>
            <div className="flex items-center gap-3 text-gray-300 text-lg sm:text-xl">
              <MapPin size={20} className="text-gold-500" /> {property.location}
            </div>
          </motion.div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 mt-8 sm:mt-16 grid grid-cols-1 lg:grid-cols-3 gap-12 sm:gap-16">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-12 sm:space-y-16">
          {/* Key Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8 py-8 sm:py-10 border-y border-white/10">
            <div className="flex flex-row sm:flex-col items-center sm:text-center gap-4 sm:gap-3">
              <div className="w-12 h-12 sm:w-14 sm:h-14 bg-luxury-800 rounded-xl sm:rounded-2xl flex items-center justify-center text-gold-500 border border-white/5 shrink-0"><Bed size={24} /></div>
              <div>
                <p className="text-xl sm:text-2xl font-serif text-white">{property.beds}</p>
                <p className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">Bedrooms</p>
              </div>
            </div>
            <div className="flex flex-row sm:flex-col items-center sm:text-center gap-4 sm:gap-3 border-y sm:border-y-0 sm:border-x border-white/5 py-4 sm:py-0">
              <div className="w-12 h-12 sm:w-14 sm:h-14 bg-luxury-800 rounded-xl sm:rounded-2xl flex items-center justify-center text-gold-500 border border-white/5 shrink-0"><Bath size={24} /></div>
              <div>
                <p className="text-xl sm:text-2xl font-serif text-white">{property.baths}</p>
                <p className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">Bathrooms</p>
              </div>
            </div>
            <div className="flex flex-row sm:flex-col items-center sm:text-center gap-4 sm:gap-3">
              <div className="w-12 h-12 sm:w-14 sm:h-14 bg-luxury-800 rounded-xl sm:rounded-2xl flex items-center justify-center text-gold-500 border border-white/5 shrink-0"><Square size={24} /></div>
              <div>
                <p className="text-xl sm:text-2xl font-serif text-white">{property.sqft.toLocaleString()}</p>
                <p className="text-[10px] uppercase tracking-widest text-gray-500 font-bold">Sq. Ft.</p>
              </div>
            </div>
          </div>

          {/* Description */}
          <section>
            <h2 className="text-3xl font-serif text-white mb-6">The Residence</h2>
            <div className="prose prose-invert max-w-none">
              <p className="text-gray-300 text-lg leading-relaxed font-light whitespace-pre-line">
                {property.description || `Experience the pinnacle of luxury living in this exquisite ${property.type.toLowerCase()}. 
                Located in the prestigious ${property.location}, this residence offers unparalleled views, 
                bespoke finishes, and world-class amenities. Every detail has been meticulously crafted 
                to provide an extraordinary lifestyle for the most discerning buyer.`}
              </p>
            </div>
          </section>

          {/* AI Neighborhood Insights */}
          <section className="bg-luxury-800/50 border border-gold-500/20 rounded-3xl p-8 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-4 text-gold-500/10 group-hover:text-gold-500/20 transition-colors">
              <Sparkles size={120} />
            </div>
            <div className="relative z-10">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 bg-gold-500/10 text-gold-500 rounded-lg">
                  <Info size={20} />
                </div>
                <h2 className="text-2xl font-serif text-white">AI Neighborhood Insights</h2>
              </div>
              
              {!insights && !loadingInsights ? (
                <button 
                  onClick={fetchInsights}
                  className="flex items-center gap-2 text-gold-500 hover:text-gold-400 transition-colors font-medium"
                >
                  <Sparkles size={18} /> Generate Location Analysis
                </button>
              ) : loadingInsights ? (
                <div className="flex items-center gap-3 text-gray-400">
                  <div className="w-5 h-5 border-2 border-gold-500 border-t-transparent rounded-full animate-spin"></div>
                  Analyzing neighborhood data...
                </div>
              ) : (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-gray-300 leading-relaxed italic"
                >
                  {insights}
                </motion.div>
              )}
            </div>
          </section>

          {/* Amenities */}
          <section>
            <h2 className="text-3xl font-serif text-white mb-8">Premium Amenities</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {(Array.isArray(property.amenities) && property.amenities.length > 0 ? property.amenities.map(a => ({ name: a, desc: '' })) : [
                { name: 'Smart Home Automation', desc: 'Fully integrated Control4 system' },
                { name: 'Private Infinity Pool', desc: 'Temperature controlled with sea views' },
                { name: '24/7 Concierge', desc: 'Personal lifestyle management' },
                { name: 'Wine Cellar', desc: 'Climate controlled for 500+ bottles' },
                { name: 'Home Theater', desc: 'Dolby Atmos 11.2 surround sound' },
                { name: 'Wellness Center', desc: 'Private gym, sauna, and steam room' }
              ]).map((amenity, i) => (
                <div key={i} className="flex items-start gap-4 p-4 bg-luxury-800/30 rounded-2xl border border-white/5 hover:border-gold-500/30 transition-colors">
                  <div className="p-2 bg-gold-500/10 text-gold-500 rounded-lg mt-1">
                    <Check size={16} />
                  </div>
                  <div>
                    <p className="text-white font-medium">{amenity.name}</p>
                    {amenity.desc && <p className="text-sm text-gray-500">{amenity.desc}</p>}
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Virtual Tour */}
          <section>
            <h2 className="text-3xl font-serif text-white mb-8">Virtual Experience</h2>
            <div 
              onClick={() => {
                trackEvent('gallery_engagement', `Property Details - ${id}`, { action: 'virtual_tour_click' });
                setShowVideo(true);
              }}
              className="relative aspect-video bg-luxury-800 rounded-3xl overflow-hidden border border-white/10 group cursor-pointer"
            >
              <img src={property.image} className="absolute inset-0 w-full h-full object-cover opacity-40 group-hover:scale-105 transition-transform duration-700" alt="Tour" />
              <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                <div className="w-20 h-20 bg-gold-500 rounded-full flex items-center justify-center text-black shadow-2xl shadow-gold-500/20 group-hover:scale-110 transition-transform">
                  <Play fill="currentColor" size={32} className="ml-1" />
                </div>
              </div>
              <div className="absolute bottom-6 left-6 text-white">
                <p className="text-sm uppercase tracking-widest opacity-60 mb-1">Interactive</p>
                <p className="text-xl font-serif">Take a 3D Walkthrough</p>
              </div>
            </div>
          </section>

          {/* Architectural Storytelling */}
          <section className="py-12 border-t border-white/10">
            <h2 className="text-3xl font-serif text-white mb-8 italic text-gold-500">
              {property.story_title || "Architectural Storytelling"}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div className="space-y-6">
                <p className="text-gray-400 leading-relaxed font-light text-lg whitespace-pre-line">
                  {property.story_text || `This residence is more than just a home; it's a masterpiece of modern architecture. Designed by award-winning visionaries, the structure harmonizes with its natural surroundings while pushing the boundaries of contemporary design.
                  
                  From the hand-selected Italian marble to the custom-engineered floor-to-ceiling glass walls, every element has been chosen to evoke a sense of timeless elegance and sophisticated comfort.`}
                </p>
              </div>
              <div className="rounded-3xl overflow-hidden h-80 border border-white/10 shadow-2xl">
                <img 
                  src={property.image} 
                  alt="Architectural Detail" 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </section>

          {/* Price History */}
          <section>
            <h2 className="text-3xl font-serif text-white mb-8">Appreciation History</h2>
            <div className="bg-luxury-800/30 border border-white/5 rounded-3xl p-8 h-[350px]">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={[
                  { year: '2021', price: 8.5 },
                  { year: '2022', price: 9.2 },
                  { year: '2023', price: 10.5 },
                  { year: '2024', price: 11.8 },
                  { year: '2025', price: 12.5 },
                ]}>
                  <defs>
                    <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#D4AF37" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                  <XAxis dataKey="year" stroke="#666" fontSize={12} axisLine={false} tickLine={false} />
                  <YAxis stroke="#666" fontSize={12} axisLine={false} tickLine={false} tickFormatter={(v) => `${currencySymbol}${v}M`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#111', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                    itemStyle={{ color: '#fff' }}
                    formatter={(value: any) => [`${currencySymbol}${value}M`, 'Value']}
                  />
                  <Area type="monotone" dataKey="price" stroke="#D4AF37" fillOpacity={1} fill="url(#colorPrice)" strokeWidth={3} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <p className="text-xs text-gray-500 mt-4 italic text-center">
              Historical data based on neighborhood averages and similar property sales.
            </p>
          </section>

          {/* Location Map */}
          <section>
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-3xl font-serif text-white">The Location</h2>
              <div className="flex items-center gap-2 text-gold-500">
                <MapPin size={18} />
                <span className="text-sm uppercase tracking-widest font-bold">{property.location}</span>
              </div>
            </div>
            <div className="w-full h-[400px] bg-luxury-800 rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
              <iframe
                width="100%"
                height="100%"
                frameBorder="0"
                style={{ border: 0, filter: 'invert(90%) hue-rotate(180deg) contrast(100%)' }}
                src={`https://maps.google.com/maps?q=${encodeURIComponent(property.location)}&t=m&z=14&output=embed&iwloc=near`}
                allowFullScreen
                title="Property Location"
              ></iframe>
            </div>
          </section>
        </div>

        {/* Sidebar / Lead Form */}
        <div className="lg:col-span-1">
          <div className="sticky top-24 space-y-8">
            <motion.div 
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="bg-luxury-800 border border-white/10 rounded-3xl p-8 shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 left-0 w-1 h-full bg-gold-500"></div>
              <p className="text-gray-500 text-xs uppercase tracking-[0.2em] mb-2">Investment Value</p>
              <p className="text-5xl font-serif text-white mb-8">{formatPrice(property.price)}</p>
              
              <button 
                onClick={() => setShowTourModal(true)}
                className="w-full py-4 bg-white text-black font-bold rounded-xl hover:bg-gray-200 transition-all flex items-center justify-center gap-2 mb-4"
              >
                <Calendar size={20} /> Schedule Private Tour
              </button>
              
              {isDownloading ? (
                <div className="w-full py-4 bg-luxury-900 border border-gold-500/30 rounded-xl mb-4 px-6">
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-[10px] text-gold-500 font-mono uppercase tracking-widest">Preparing Brochure</span>
                    <span className="text-[10px] text-gold-500 font-mono">{downloadProgress}%</span>
                  </div>
                  <div className="h-1 bg-black rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full bg-gold-500"
                      initial={{ width: 0 }}
                      animate={{ width: `${downloadProgress}%` }}
                    />
                  </div>
                </div>
              ) : (
                <button 
                  onClick={() => {
                    trackEvent('brochure_download', `Property Details - ${id}`, { property: property.title });
                    simulateDownload();
                  }}
                  className="w-full py-4 bg-luxury-900 text-white border border-white/10 font-bold rounded-xl hover:bg-white/5 transition-all flex items-center justify-center gap-2 mb-4"
                >
                  <Download size={20} /> Download Digital Brochure
                </button>
              )}
              
              <p className="text-center text-xs text-gray-500">Available for in-person or virtual viewings</p>
            </motion.div>

            <MortgageCalculator propertyPrice={formatPrice(property.price)} />

            <div className="bg-luxury-800/50 border border-white/5 rounded-3xl p-8">
              <h3 className="text-xl font-serif text-white mb-6">Inquire About This Property</h3>
              <LeadForm source={`Property Inquiry: ${property.title}`} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
