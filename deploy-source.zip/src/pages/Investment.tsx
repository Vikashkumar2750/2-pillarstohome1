import React, { useEffect } from 'react';
import { useTracking } from '../hooks/useTracking';
import { useContent } from '../hooks/useContent';
import { LeadForm } from '../components/LeadForm';
import { DreamHomeVisualizer } from '../components/DreamHomeVisualizer';
import { TrendingUp, PieChart, Landmark, ArrowUpRight, Zap } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const marketData = [
  { year: '2020', Dubai: 100, London: 100, Mumbai: 100 },
  { year: '2021', Dubai: 112, London: 105, Mumbai: 108 },
  { year: '2022', Dubai: 128, London: 108, Mumbai: 115 },
  { year: '2023', Dubai: 145, London: 110, Mumbai: 130 },
  { year: '2024', Dubai: 168, London: 115, Mumbai: 155 },
  { year: '2025', Dubai: 195, London: 122, Mumbai: 185 },
];

export const Investment = () => {
  const { trackEvent } = useTracking();
  const { content } = useContent('investment');

  useEffect(() => {
    trackEvent('page_view', 'Investment & NRI');
  }, [trackEvent]);

  return (
    <div className="min-h-screen bg-luxury-900 pt-20 pb-24">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-20">
          <div>
            <div className="inline-block bg-gold-500/10 text-gold-500 px-4 py-1 rounded-full text-sm font-medium mb-6 border border-gold-500/20">
              NRI & Foreign Investment
            </div>
            <h1 className="text-4xl md:text-6xl font-serif text-white mb-6 leading-tight"
              dangerouslySetInnerHTML={{ __html: content.hero_title || 'Secure Your Wealth in Premium Real Estate' }}
            />
            <p className="text-lg text-gray-400 font-light leading-relaxed mb-8">
              {content.hero_subtitle || "We offer end-to-end investment advisory for Non-Resident Indians and global investors looking to capitalize on high-yield luxury real estate markets in Dubai and India."}
            </p>
            <div className="space-y-6">
              {[
                { 
                  title: content.feature1_title || "High ROI Potential", 
                  desc: content.feature1_desc || "Historically, our curated projects yield 8-12% annual capital appreciation.",
                  icon: content.feature1_icon || "TrendingUp"
                },
                { 
                  title: content.feature2_title || "Tax Advisory & Compliance", 
                  desc: content.feature2_desc || "Complete legal and tax structuring assistance for cross-border investments.",
                  icon: content.feature2_icon || "Landmark"
                },
                { 
                  title: content.feature3_title || "Portfolio Management", 
                  desc: content.feature3_desc || "Post-purchase property management and rental yield optimization.",
                  icon: content.feature3_icon || "PieChart"
                }
              ].map((feature, i) => {
                const IconComponent = (LucideIcons as any)[feature.icon] || LucideIcons.Zap;
                return (
                  <div key={i} className="flex gap-4">
                    <div className="mt-1 text-gold-500"><IconComponent /></div>
                    <div>
                      <h3 className="text-white font-medium text-lg">{feature.title}</h3>
                      <p className="text-gray-400 text-sm">{feature.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          <div className="relative">
            <div className="absolute -inset-4 bg-gradient-to-r from-gold-500/20 to-purple-500/20 blur-2xl rounded-full opacity-50"></div>
            <LeadForm source="Investment Page" />
          </div>
        </div>

        {/* Market Insights Section */}
        <div className="mb-24">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif text-white mb-4">{content.market_title || "2026 Market Intelligence"}</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">{content.market_subtitle || "Comparative analysis of capital appreciation across prime global markets."}</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mb-16">
            <div className="lg:col-span-2 bg-luxury-800/50 p-6 sm:p-8 rounded-3xl border border-white/5 h-[350px] sm:h-[450px]">
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-xl font-serif text-white">Price Appreciation Index (5Y)</h3>
                <div className="flex gap-4 text-xs font-medium">
                  <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-gold-500"></span> Dubai</div>
                  <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-blue-500"></span> Mumbai</div>
                  <div className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-gray-500"></span> London</div>
                </div>
              </div>
              <ResponsiveContainer width="100%" height="80%">
                <AreaChart data={marketData}>
                  <defs>
                    <linearGradient id="colorDubai" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#D4AF37" stopOpacity={0.3}/>
                      <stop offset="95%" stopColor="#D4AF37" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#333" vertical={false} />
                  <XAxis dataKey="year" stroke="#666" fontSize={12} axisLine={false} tickLine={false} />
                  <YAxis stroke="#666" fontSize={12} axisLine={false} tickLine={false} tickFormatter={(v) => `${v}%`} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#111', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '12px' }}
                    itemStyle={{ color: '#fff' }}
                  />
                  <Area type="monotone" dataKey="Dubai" stroke="#D4AF37" fillOpacity={1} fill="url(#colorDubai)" strokeWidth={3} />
                  <Area type="monotone" dataKey="Mumbai" stroke="#3b82f6" fillOpacity={0} strokeWidth={2} />
                  <Area type="monotone" dataKey="London" stroke="#666" fillOpacity={0} strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-6">
              {[
                { city: 'Dubai', yield: '7.5%', growth: '+12%', trend: 'Bullish', desc: 'Driven by golden visa reforms and zero tax environment.' },
                { city: 'London', yield: '4.2%', growth: '+5%', trend: 'Stable', desc: 'Safe haven asset with consistent long-term appreciation.' },
                { city: 'Mumbai', yield: '3.8%', growth: '+15%', trend: 'High Growth', desc: 'Infrastructure boom in Navi Mumbai and South Mumbai.' }
              ].map((insight, i) => (
                <div key={i} className="bg-luxury-800 border border-white/5 p-6 rounded-2xl hover:border-gold-500/30 transition-all group">
                  <div className="flex justify-between items-start mb-4">
                    <h3 className="text-xl font-serif text-white">{insight.city}</h3>
                    <ArrowUpRight size={18} className="text-gray-600 group-hover:text-gold-500 transition-colors" />
                  </div>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div>
                      <p className="text-[10px] text-gray-500 uppercase tracking-widest">Rental Yield</p>
                      <p className="text-lg font-medium text-gold-500">{insight.yield}</p>
                    </div>
                    <div>
                      <p className="text-[10px] text-gray-500 uppercase tracking-widest">Growth</p>
                      <p className="text-lg font-medium text-green-500">{insight.growth}</p>
                    </div>
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed">{insight.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* AI Visualizer Section */}
        <div className="mb-24">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-serif text-white mb-4">{content.visualizer_title || "Visualize Your Future"}</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">{content.visualizer_subtitle || "Use our AI architectural visualizer to explore high-end design concepts for your next residence."}</p>
          </div>
          <DreamHomeVisualizer />
        </div>

        {/* Investment Philosophy */}
        <div className="bg-luxury-800 rounded-3xl p-8 md:p-12 border border-white/5 relative overflow-hidden text-center">
          <div className="relative z-10 max-w-3xl mx-auto">
            <h2 className="text-3xl font-serif text-white mb-6">{content.philosophy_title || "Our Investment Philosophy"}</h2>
            <p className="text-gray-400 font-light leading-relaxed mb-8">
              {content.philosophy_text || "We don't just sell properties; we curate wealth-building opportunities. Our selection process involves rigorous due diligence on developer track records, location infrastructure growth, and historical secondary market performance."}
            </p>
            <div className="flex flex-wrap justify-center gap-8 md:gap-16">
              <div className="text-center">
                <p className="text-3xl font-serif text-gold-500">{content.stat1_value || "$2.4B+"}</p>
                <p className="text-[10px] text-gray-500 uppercase tracking-widest mt-1">{content.stat1_label || "Assets Managed"}</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-serif text-gold-500">{content.stat2_value || "14%"}</p>
                <p className="text-[10px] text-gray-500 uppercase tracking-widest mt-1">{content.stat2_label || "Avg. Annual Return"}</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-serif text-gold-500">{content.stat3_value || "12"}</p>
                <p className="text-[10px] text-gray-500 uppercase tracking-widest mt-1">{content.stat3_label || "Global Markets"}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
