import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTracking } from '../hooks/useTracking';
import { useContent } from '../hooks/useContent';
import { useCurrency } from '../contexts/CurrencyContext';
import { LeadForm } from '../components/LeadForm';
import { Building, MapPin, ArrowRight, Loader2, CheckCircle2, Download, Globe, Zap } from 'lucide-react';
import * as LucideIcons from 'lucide-react';
import { Link } from 'react-router-dom';
import { VideoModal } from '../components/VideoModal';

export const Home = () => {
  const { trackEvent, submitFullLead } = useTracking();
  const { content } = useContent('home');
  const { formatPrice } = useCurrency();
  const [properties, setProperties] = useState<any[]>([]);
  const [detectedLocation, setDetectedLocation] = useState<{ city: string, zip: string, segment: string } | null>(null);
  const [showReportForm, setShowReportForm] = useState(false);
  const [reportUnlocked, setReportUnlocked] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [showVideo, setShowVideo] = useState(false);

  useEffect(() => {
    trackEvent('page_view', 'Home');
    
    // Real Geofencing / IP Geolocation using ipapi.co (HTTPS support)
    const fetchGeo = async () => {
      try {
        const res = await fetch('https://ipapi.co/json/');
        const data = await res.json();
        if (data.city) {
          const highNetWorthZipCodes = ['10021', '90210', 'SW1X', '400006']; // NY, Beverly Hills, London, Mumbai
          const isHNW = highNetWorthZipCodes.includes(data.postal) || Math.random() > 0.7; // Simulate HNW for demo if not in list
          
          const geoInfo = {
            city: data.city,
            zip: data.postal,
            segment: isHNW ? 'HNW' : 'Standard'
          };
          
          setDetectedLocation(geoInfo);
          trackEvent('geo_detected', 'Home', geoInfo);
        }
      } catch (err) {
        // Fallback to simulation if blocked by adblocker/CORS
        const simulateGeo = () => {
          const highNetWorthZipCodes = ['10021', '90210', 'SW1X', '400006'];
          const randomZip = highNetWorthZipCodes[Math.floor(Math.random() * highNetWorthZipCodes.length)];
          setDetectedLocation({ city: 'Beverly Hills', zip: randomZip, segment: 'HNW' });
          trackEvent('geo_detected', 'Home', { zip: randomZip, segment: 'HNW' });
        };
        setTimeout(simulateGeo, 1500);
      }
    };
    
    fetchGeo();

    fetch('/api/properties')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setProperties(data);
        } else {
          setProperties([]);
        }
      })
      .catch(error => {
        console.error("Error fetching properties:", error);
        setProperties([]);
      });
  }, [trackEvent]);

  const handleReportUnlock = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const data = {
      name: formData.get('name'),
      email: formData.get('email'),
      source: 'Market Report Gated',
      type: 'Report Download'
    };
    
    try {
      await submitFullLead(data);
      trackEvent('report_unlock', 'Home', { report: 'Q1 2026 Luxury Outlook' });
      setReportUnlocked(true);
      setShowReportForm(false);
    } catch (err) {
      console.error(err);
    }
  };

  const simulateDownload = () => {
    setIsDownloading(true);
    setDownloadProgress(0);
    const interval = setInterval(() => {
      setDownloadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => setIsDownloading(false), 1000);
          return 100;
        }
        return prev + 5;
      });
    }, 100);
  };

  return (
    <div className="min-h-screen">
      <VideoModal 
        isOpen={showVideo} 
        onClose={() => setShowVideo(false)} 
        videoUrl={content.hero_video_url || "https://www.youtube.com/watch?v=0k_v9E_7v6c"} 
        title="PillarstoHome: The Global Luxury Collection"
      />

      {/* Geofencing Welcome Banner */}
      {detectedLocation && (
        <motion.div 
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: 'auto', opacity: 1 }}
          className="bg-gold-500 text-black py-2 px-4 text-center text-xs font-bold uppercase tracking-widest z-50 relative"
        >
          Exclusive Opportunities Detected for <span className="underline">{detectedLocation.city} ({detectedLocation.zip})</span> Residents. <Link to="/listings" className="ml-2 border-b border-black">View Private Collection</Link>
        </motion.div>
      )}

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src={content.hero_image || "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80"} 
            alt="Luxury Real Estate" 
            className="w-full h-full object-cover opacity-40"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-luxury-900/50 via-luxury-900/20 to-luxury-900"></div>
        </div>
        
        <div className="relative z-10 text-center px-4 max-w-5xl mx-auto mt-20">
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1 }}
            className="text-4xl sm:text-5xl md:text-7xl font-serif mb-6 leading-tight"
            dangerouslySetInnerHTML={{ __html: content.hero_title || 'Discover Exceptional <br/> <span class="text-gold-500 italic">Living Spaces</span>' }}
          />
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.3 }}
            className="text-base sm:text-lg md:text-xl text-gray-300 mb-10 max-w-2xl mx-auto font-light"
          >
            {content.hero_subtitle || "Curated luxury properties in the world's most exclusive destinations."}
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.6 }}
          >
            <Link to={content.hero_cta_link || "/listings"} className="inline-flex items-center gap-2 bg-white text-black px-6 sm:px-8 py-3 sm:py-4 rounded-full hover:bg-gold-500 transition-colors font-medium text-sm sm:text-base">
              {content.hero_cta_text || "View Collection"} <ArrowRight size={18} />
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-12 bg-black border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8 text-center">
            <div className="space-y-2">
              <p className="text-3xl sm:text-4xl font-serif text-gold-500">{content.stats_stat1_value || "$4.2B"}</p>
              <p className="text-[10px] sm:text-xs uppercase tracking-widest text-gray-500 font-bold">{content.stats_stat1_label || "Assets Managed"}</p>
            </div>
            <div className="space-y-2 border-y sm:border-y-0 sm:border-x border-white/10 py-8 sm:py-0">
              <p className="text-3xl sm:text-4xl font-serif text-gold-500">{content.stats_stat2_value || "120+"}</p>
              <p className="text-[10px] sm:text-xs uppercase tracking-widest text-gray-500 font-bold">{content.stats_stat2_label || "Global Partners"}</p>
            </div>
            <div className="space-y-2">
              <p className="text-3xl sm:text-4xl font-serif text-gold-500">{content.stats_stat3_value || "15"}</p>
              <p className="text-[10px] sm:text-xs uppercase tracking-widest text-gray-500 font-bold">{content.stats_stat3_label || "Years Excellence"}</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Market Trends Ticker */}
      <div className="bg-black/50 backdrop-blur-md border-y border-white/5 py-4 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-12 whitespace-nowrap animate-marquee">
          {[
            { city: 'Dubai', growth: '+12.4%', status: 'Bullish' },
            { city: 'London', growth: '+4.8%', status: 'Stable' },
            { city: 'Mumbai', growth: '+15.2%', status: 'High Growth' },
            { city: 'Singapore', growth: '+6.1%', status: 'Stable' },
            { city: 'New York', growth: '+3.2%', status: 'Recovering' },
            { city: 'Paris', growth: '+5.5%', status: 'Bullish' },
          ].map((trend, i) => (
            <div key={i} className="flex items-center gap-3">
              <span className="text-xs font-medium text-gray-500 uppercase tracking-widest">{trend.city}</span>
              <span className="text-sm font-bold text-gold-500">{trend.growth}</span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full ${trend.status === 'Bullish' || trend.status === 'High Growth' ? 'bg-green-500/10 text-green-500' : 'bg-blue-500/10 text-blue-400'}`}>
                {trend.status}
              </span>
            </div>
          ))}
          {/* Duplicate for seamless loop */}
          {[
            { city: 'Dubai', growth: '+12.4%', status: 'Bullish' },
            { city: 'London', growth: '+4.8%', status: 'Stable' },
            { city: 'Mumbai', growth: '+15.2%', status: 'High Growth' },
            { city: 'Singapore', growth: '+6.1%', status: 'Stable' },
            { city: 'New York', growth: '+3.2%', status: 'Recovering' },
            { city: 'Paris', growth: '+5.5%', status: 'Bullish' },
          ].map((trend, i) => (
            <div key={`dup-${i}`} className="flex items-center gap-3">
              <span className="text-xs font-medium text-gray-500 uppercase tracking-widest">{trend.city}</span>
              <span className="text-sm font-bold text-gold-500">{trend.growth}</span>
              <span className={`text-[10px] px-2 py-0.5 rounded-full ${trend.status === 'Bullish' || trend.status === 'High Growth' ? 'bg-green-500/10 text-green-500' : 'bg-blue-500/10 text-blue-400'}`}>
                {trend.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Cinematic Property Tours */}
      <section className="py-24 bg-black relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="flex flex-col md:flex-row items-center gap-16">
            <div className="w-full md:w-1/2">
              <h2 className="text-4xl md:text-6xl font-serif mb-8 leading-tight">
                Architectural <br/>
                <span className="text-gold-500 italic">Storytelling</span>
              </h2>
              <p className="text-gray-400 text-lg mb-10 font-light leading-relaxed">
                Experience luxury through 4K cinematic property tours. Our professional filmmakers capture the soul of every property, telling the story of its architectural heritage and design philosophy.
              </p>
              <button 
                onClick={() => {
                  trackEvent('cinematic_tour_play', 'Home', { video: 'Global Portfolio' });
                  setShowVideo(true);
                }}
                className="flex items-center gap-4 group"
              >
                <div className="w-16 h-16 rounded-full border border-gold-500 flex items-center justify-center group-hover:bg-gold-500 transition-all">
                  <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[12px] border-l-gold-500 border-b-[8px] border-b-transparent ml-1 group-hover:border-l-black"></div>
                </div>
                <span className="text-sm font-bold uppercase tracking-widest group-hover:text-gold-500 transition-colors">Watch 4K Showreel</span>
              </button>
            </div>
            <div className="w-full md:w-1/2 relative">
              <div 
                onClick={() => setShowVideo(true)}
                className="aspect-video rounded-3xl overflow-hidden border border-white/10 group cursor-pointer relative"
              >
                <img 
                  src="https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80" 
                  alt="Cinematic Tour Preview" 
                  className="w-full h-full object-cover opacity-80 group-hover:scale-105 transition-transform duration-1000"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-luxury-900/20 group-hover:bg-luxury-900/0 transition-colors"></div>
              </div>
              <div className="absolute -bottom-6 -right-6 bg-gold-500 text-black p-6 rounded-2xl shadow-2xl hidden md:block">
                <p className="text-xs font-bold uppercase tracking-widest mb-1">Upcoming Premiere</p>
                <p className="text-lg font-serif">The Azure Penthouse, Dubai</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Gated Market Insights Section */}
      <section className="py-24 bg-luxury-900 relative overflow-hidden border-y border-white/5">
        <div className="max-w-7xl mx-auto px-4 relative z-10">
          <div className="bg-luxury-800/50 rounded-[40px] p-12 md:p-20 border border-white/5 flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2">
              <span className="text-gold-500 text-xs font-bold uppercase tracking-widest mb-4 block">Exclusive Intelligence</span>
              <h2 className="text-4xl md:text-5xl font-serif mb-6">{content.report_title || "Q1 2026 Global Luxury Real Estate Outlook"}</h2>
              <p className="text-gray-400 mb-8 leading-relaxed">
                {content.report_subtitle || "Gain access to our proprietary market analysis. This exclusive report covers emerging investment corridors, tax implications for HNWIs, and high-yield luxury rental trends in Dubai, London, and Singapore."}
              </p>
              <ul className="space-y-4 text-sm text-gray-300 mb-10">
                <li className="flex items-center gap-3"><Building size={16} className="text-gold-500" /> Top 10 Emerging Luxury Corridors</li>
                <li className="flex items-center gap-3"><Building size={16} className="text-gold-500" /> HNWI Investment Sentiment Audit</li>
                <li className="flex items-center gap-3"><Building size={16} className="text-gold-500" /> Yield Projections for Off-Market Assets</li>
              </ul>
            </div>
            <div className="lg:w-1/2 w-full">
              {!reportUnlocked ? (
                <div className="bg-black/40 p-8 rounded-3xl border border-white/10 backdrop-blur-sm">
                  <h3 className="text-xl font-serif mb-6 text-center">Unlock the Report</h3>
                  <form onSubmit={handleReportUnlock} className="space-y-4">
                    <input 
                      name="name"
                      type="text" 
                      placeholder="Full Name" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-gold-500 transition-colors outline-none"
                    />
                    <input 
                      name="email"
                      type="email" 
                      placeholder="Professional Email" 
                      required
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white focus:border-gold-500 transition-colors outline-none"
                    />
                    <button 
                      type="submit"
                      className="w-full bg-gold-500 text-black font-bold py-4 rounded-xl hover:bg-gold-600 transition-colors uppercase tracking-widest text-xs"
                    >
                      {content.report_cta_text || "Access Exclusive Insights"}
                    </button>
                  </form>
                  <p className="text-[10px] text-gray-500 mt-4 text-center">
                    By accessing this report, you agree to our privacy policy and terms of service.
                  </p>
                </div>
              ) : (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-gold-500/10 p-12 rounded-3xl border border-gold-500/30 text-center"
                >
                  <div className="w-20 h-20 bg-gold-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 size={32} className="text-black" />
                  </div>
                  <h3 className="text-2xl font-serif mb-4">Report Unlocked</h3>
                  <p className="text-gray-300 mb-8">Your copy of the Q1 2026 Luxury Outlook is ready for download.</p>
                  
                  {isDownloading ? (
                    <div className="max-w-xs mx-auto space-y-4">
                      <div className="h-2 bg-black rounded-full overflow-hidden">
                        <motion.div 
                          className="h-full bg-gold-500"
                          initial={{ width: 0 }}
                          animate={{ width: `${downloadProgress}%` }}
                        />
                      </div>
                      <p className="text-xs text-gold-500 font-mono flex items-center justify-center gap-2">
                        <Loader2 size={12} className="animate-spin" /> GENERATING SECURE PDF... {downloadProgress}%
                      </p>
                    </div>
                  ) : (
                    <button 
                      onClick={simulateDownload}
                      className="flex items-center gap-3 px-10 py-4 bg-gold-500 text-black font-bold rounded-full hover:bg-gold-600 transition-all mx-auto"
                    >
                      <Download size={20} /> Download PDF Now
                    </button>
                  )}
                </motion.div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Featured Properties */}
      <section className="py-24 px-4 max-w-7xl mx-auto">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-serif mb-2">{content.featured_title || "Featured Collection"}</h2>
            <p className="text-gray-400">{content.featured_subtitle || "Exclusive properties handpicked for you."}</p>
          </div>
          <Link to="/listings" className="hidden md:flex items-center gap-2 text-gold-500 hover:text-gold-600 transition-colors">
            View All <ArrowRight size={16} />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {properties.filter(p => p.featured).map((prop, i) => (
            <Link to={`/property/${prop.id}`} key={prop.id}>
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="group cursor-pointer"
              >
                <div className="relative h-80 overflow-hidden rounded-2xl mb-4">
                  <img 
                    src={prop.image} 
                    alt={prop.title} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80";
                    }}
                  />
                  <div className="absolute top-4 left-4 bg-black/50 backdrop-blur-md px-3 py-1 rounded-full text-xs font-medium border border-white/10">
                    {prop.type}
                  </div>
                </div>
                <h3 className="text-xl font-serif mb-2 group-hover:text-gold-500 transition-colors">{prop.title}</h3>
                <div className="flex items-center gap-2 text-gray-400 text-sm mb-3">
                  <MapPin size={14} /> {prop.location}
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-lg font-medium">{formatPrice(prop.price)}</span>
                  <div className="flex gap-4 text-sm text-gray-400">
                    <span>{prop.beds} Beds</span>
                    <span>{prop.baths} Baths</span>
                  </div>
                </div>
              </motion.div>
            </Link>
          ))}
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 px-4 max-w-7xl mx-auto border-t border-white/5">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-serif mb-4">{content.why_title || "Why Choose PillarstoHome"}</h2>
          <p className="text-gray-400 max-w-2xl mx-auto">{content.why_subtitle || "We redefine luxury real estate through technology, expertise, and personalized service."}</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {[
            { 
              title: content.why_feature1_title || "AI-Powered Insights", 
              desc: content.why_feature1_desc || "Our advanced AI concierge helps qualify your needs and provides personalized property recommendations in real-time.",
              icon: content.why_feature1_icon || "Zap"
            },
            { 
              title: content.why_feature2_title || "Exclusive Inventory", 
              desc: content.why_feature2_desc || "Gain access to off-market listings and premium developments before they hit the general market.",
              icon: content.why_feature2_icon || "Building"
            },
            { 
              title: content.why_feature3_title || "Global Network", 
              desc: content.why_feature3_desc || "With experts in London, Dubai, and Mumbai, we provide a truly international perspective on luxury investments.",
              icon: content.why_feature3_icon || "Globe"
            }
          ].map((item, i) => {
            const IconComponent = (LucideIcons as any)[item.icon] || LucideIcons.Zap;
            return (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="p-8 bg-luxury-800/50 rounded-3xl border border-white/5 hover:border-gold-500/30 transition-all group"
              >
                <div className="w-12 h-12 bg-gold-500/10 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-gold-500 transition-colors">
                  <IconComponent size={24} className="text-gold-500 group-hover:text-black transition-colors" />
                </div>
                <h3 className="text-xl font-serif mb-4">{item.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{item.desc}</p>
              </motion.div>
            );
          })}
        </div>
      </section>

      {/* Lead Capture Section */}
      <section className="py-24 bg-luxury-800 border-y border-white/5 relative overflow-hidden">
        <div className="absolute right-0 top-0 w-1/2 h-full opacity-10 pointer-events-none">
           <Building size={400} className="absolute -right-20 -top-20 text-gold-500" />
        </div>
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div>
            <h2 className="text-4xl font-serif mb-6">{content.lead_capture_title || "Let us find your dream home."}</h2>
            <p className="text-gray-400 mb-8 text-lg font-light leading-relaxed">
              {content.lead_capture_subtitle || "Our dedicated team of luxury real estate experts is ready to assist you in finding the perfect property that matches your lifestyle and investment goals."}
            </p>
            <ul className="space-y-4 text-gray-300">
              <li className="flex items-center gap-3"><div className="w-1.5 h-1.5 rounded-full bg-gold-500"></div> {content.lead_capture_bullet1 || "Off-market opportunities"}</li>
              <li className="flex items-center gap-3"><div className="w-1.5 h-1.5 rounded-full bg-gold-500"></div> {content.lead_capture_bullet2 || "Personalized property tours"}</li>
              <li className="flex items-center gap-3"><div className="w-1.5 h-1.5 rounded-full bg-gold-500"></div> {content.lead_capture_bullet3 || "Expert negotiation"}</li>
            </ul>
          </div>
          <div>
            <LeadForm source="Home Page Bottom" />
          </div>
        </div>
      </section>
    </div>
  );
};
