import React from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { FileText, Scale, AlertTriangle, Copyright } from 'lucide-react';

const Terms = () => {
  const sections = [
    {
      icon: <Scale className="w-6 h-6 text-gold-500" />,
      title: "1. Agreement to Terms",
      content: "By accessing or using our services, you agree to be bound by these Terms of Service and all applicable laws and regulations. If you do not agree with any of these terms, you are prohibited from using or accessing this site."
    },
    {
      icon: <FileText className="w-6 h-6 text-gold-500" />,
      title: "2. Use License",
      content: "Permission is granted to temporarily download one copy of the materials (information or software) on PillarstoHome Real Estate's website for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not modify or copy the materials, use the materials for any commercial purpose, or attempt to decompile or reverse engineer any software."
    },
    {
      icon: <AlertTriangle className="w-6 h-6 text-gold-500" />,
      title: "3. Disclaimer",
      content: "The materials on PillarstoHome Real Estate's website are provided on an 'as is' basis. PillarstoHome Real Estate makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including, without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights."
    },
    {
      icon: <Copyright className="w-6 h-6 text-gold-500" />,
      title: "4. Limitations",
      content: "In no event shall PillarstoHome Real Estate or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on PillarstoHome Real Estate's website, even if PillarstoHome Real Estate or a PillarstoHome Real Estate authorized representative has been notified orally or in writing of the possibility of such damage."
    }
  ];

  return (
    <main className="min-h-screen bg-stone-50 pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-serif text-stone-900 mb-6">Terms of Service</h1>
          <p className="text-lg text-stone-600 max-w-2xl mx-auto">
            Please read these terms and conditions carefully before using the PillarstoHome Real Estate platform.
          </p>
          <p className="text-sm text-stone-500 mt-4">Last Updated: March 24, 2026</p>
        </motion.div>

        <div className="space-y-12">
          {sections.map((section, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white p-8 rounded-2xl shadow-sm border border-stone-100"
            >
              <div className="flex items-start gap-4">
                <div className="p-3 bg-stone-50 rounded-xl">
                  {section.icon}
                </div>
                <div>
                  <h2 className="text-2xl font-serif text-stone-900 mb-4">{section.title}</h2>
                  <p className="text-stone-600 leading-relaxed">
                    {section.content}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 p-8 bg-luxury-900 text-white rounded-2xl text-center"
        >
          <h2 className="text-2xl font-serif mb-4">Need Legal Assistance?</h2>
          <p className="text-stone-300 mb-6">
            Our legal team is available to answer any questions regarding our terms of service.
          </p>
          <Link 
            to="/contact" 
            className="inline-block px-8 py-3 bg-gold-500 text-white font-medium rounded-full hover:bg-gold-600 transition-colors"
          >
            Contact Legal Team
          </Link>
        </motion.div>
      </div>
    </main>
  );
};

export default Terms;
