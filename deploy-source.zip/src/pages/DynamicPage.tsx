import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { motion } from 'motion/react';
import { ArrowRight, CheckCircle2, Building2, MapPin, Phone, Mail } from 'lucide-react';

interface Section {
  id: number;
  section_type: string;
  title: string;
  subtitle: string;
  content: string;
  order_index: number;
}

interface Page {
  id: number;
  slug: string;
  title: string;
  show_header: boolean;
  show_footer: boolean;
}

const DynamicPage: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  const [page, setPage] = useState<Page | null>(null);
  const [sections, setSections] = useState<Section[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchPageData = async () => {
      try {
        setLoading(true);
        const pageResponse = await fetch(`/api/pages/${slug || 'home'}`);
        if (!pageResponse.ok) throw new Error('Page not found');
        const pageData = await pageResponse.json();
        setPage(pageData);

        const sectionsResponse = await fetch(`/api/pages/${slug || 'home'}/sections`);
        if (sectionsResponse.ok) {
          const sectionsData = await sectionsResponse.json();
          setSections(sectionsData);
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchPageData();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-stone-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-stone-800"></div>
      </div>
    );
  }

  if (error || !page) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-stone-50">
        <div className="text-center">
          <h1 className="text-4xl font-serif mb-4 text-stone-900">404</h1>
          <p className="text-stone-600">Page not found</p>
        </div>
      </div>
    );
  }

  const renderSection = (section: Section) => {
    switch (section.section_type) {
      case 'hero':
        return (
          <section key={section.id} className="relative h-[80vh] flex items-center justify-center overflow-hidden bg-stone-900">
            <div className="absolute inset-0 opacity-40">
              <img 
                src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&q=80" 
                alt="Hero Background"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="relative z-10 text-center px-4 max-w-4xl">
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-5xl md:text-7xl font-serif text-white mb-6"
              >
                {section.title}
              </motion.h1>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-xl text-stone-200 mb-8"
              >
                {section.subtitle}
              </motion.p>
              {section.content && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="prose prose-invert max-w-none text-stone-300"
                  dangerouslySetInnerHTML={{ __html: section.content }}
                />
              )}
            </div>
          </section>
        );

      case 'features':
        return (
          <section key={section.id} className="py-24 bg-white">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-serif text-stone-900 mb-4">{section.title}</h2>
                <p className="text-lg text-stone-600 max-w-2xl mx-auto">{section.subtitle}</p>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
                {/* Example feature rendering - in a real app, content might be JSON */}
                <div className="prose max-w-none text-stone-600" dangerouslySetInnerHTML={{ __html: section.content }} />
              </div>
            </div>
          </section>
        );

      case 'content':
      default:
        return (
          <section key={section.id} className="py-24 bg-stone-50">
            <div className="max-w-4xl mx-auto px-4">
              <div className="mb-12">
                <h2 className="text-3xl font-serif text-stone-900 mb-4">{section.title}</h2>
                <p className="text-lg text-stone-600">{section.subtitle}</p>
              </div>
              <div className="prose prose-stone max-w-none" dangerouslySetInnerHTML={{ __html: section.content }} />
            </div>
          </section>
        );
    }
  };

  return (
    <main className="min-h-screen">
      {sections.length > 0 ? (
        sections.map(renderSection)
      ) : (
        <section className="py-24 bg-stone-50">
          <div className="max-w-4xl mx-auto px-4 text-center">
            <h1 className="text-4xl font-serif text-stone-900 mb-4">{page.title}</h1>
            <p className="text-stone-600">This page is currently empty. Add sections in the admin dashboard.</p>
          </div>
        </section>
      )}
    </main>
  );
};

export default DynamicPage;
