import React, { useEffect } from 'react';
import { useTracking } from '../hooks/useTracking';
import { useContent } from '../hooks/useContent';
import { motion } from 'framer-motion';
import { Shield, Globe, Award, Zap } from 'lucide-react';
import * as LucideIcons from 'lucide-react';

export const About = () => {
  const { trackEvent } = useTracking();
  const { content } = useContent('about');

  useEffect(() => {
    trackEvent('page_view', 'About');
  }, [trackEvent]);

  const features = [
    { 
      title: content.feature1_title || "Global Reach", 
      desc: content.feature1_desc || "Access to off-market properties in London, Dubai, New York, and Mumbai.",
      icon: content.feature1_icon || "Globe"
    },
    { 
      title: content.feature2_title || "Absolute Discretion", 
      desc: content.feature2_desc || "We protect our clients' privacy with military-grade confidentiality agreements.",
      icon: content.feature2_icon || "Shield"
    },
    { 
      title: content.feature3_title || "Award-Winning", 
      desc: content.feature3_desc || "Recognized as the leading luxury brokerage in the Middle East and Asia.",
      icon: content.feature3_icon || "Award"
    }
  ];

  return (
    <div className="min-h-screen bg-luxury-900 pt-20 pb-24">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl md:text-6xl font-serif text-white mb-6"
            dangerouslySetInnerHTML={{ __html: content.hero_title || 'Redefining Luxury Real Estate' }}
          />
          <motion.p 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="text-lg text-gray-400 font-light leading-relaxed"
          >
            {content.hero_subtitle || "PillarstoHome Real Estate is a premier boutique brokerage specializing in the world's most exclusive properties. We provide unparalleled service, discretion, and expertise to ultra-high-net-worth individuals globally."}
          </motion.p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-24">
          {features.map((feature, i) => {
            const IconComponent = (LucideIcons as any)[feature.icon] || LucideIcons.Zap;
            return (
              <div key={i} className="text-center">
                <div className="w-16 h-16 mx-auto bg-luxury-800 rounded-full flex items-center justify-center text-gold-500 mb-6">
                  <IconComponent size={32} />
                </div>
                <h3 className="text-xl font-serif text-white mb-3">{feature.title}</h3>
                <p className="text-gray-400 font-light">{feature.desc}</p>
              </div>
            );
          })}
        </div>

        <div className="relative h-[500px] rounded-3xl overflow-hidden">
          <img 
            src={content.vision_image || "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?ixlib=rb-4.0.3&auto=format&fit=crop&w=2000&q=80"} 
            alt="Luxury Interior" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <div className="text-center px-4">
              <p className="text-gold-500 font-medium tracking-widest uppercase mb-2">{content.vision_label || "Our Vision"}</p>
              <h2 className="text-3xl md:text-5xl font-serif text-white max-w-2xl mx-auto leading-tight">
                "{content.vision_text || "To curate the world's finest living experiences for those who demand nothing but the best."}"
              </h2>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
