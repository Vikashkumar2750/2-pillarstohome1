import React from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { Shield, Lock, Eye, FileText } from 'lucide-react';

const Privacy = () => {
  const sections = [
    {
      icon: <Eye className="w-6 h-6 text-gold-500" />,
      title: "1. Information We Collect",
      content: "We collect information that you provide directly to us, including your name, email address, phone number, and any other information you choose to provide when you contact us, subscribe to our newsletter, or use our services. We also automatically collect certain information about your device and how you interact with our website."
    },
    {
      icon: <Lock className="w-6 h-6 text-gold-500" />,
      title: "2. How We Use Your Information",
      content: "We use the information we collect to provide, maintain, and improve our services, communicate with you, personalize your experience, and protect against fraudulent or illegal activity. Your data helps us tailor our property recommendations to your specific luxury real estate preferences."
    },
    {
      icon: <Shield className="w-6 h-6 text-gold-500" />,
      title: "3. Information Sharing",
      content: "We do not sell your personal information. We may share your information with third-party service providers who perform services on our behalf, such as hosting, analytics, and customer service. We require all third parties to respect the security of your personal data and to treat it in accordance with the law."
    },
    {
      icon: <FileText className="w-6 h-6 text-gold-500" />,
      title: "4. Your Privacy Rights",
      content: "Depending on your location, you may have the right to access, correct, or delete your personal information. You may also have the right to object to or restrict certain processing of your data. To exercise these rights, please contact our dedicated privacy team."
    }
  ];

  return (
    <main className="min-h-screen bg-stone-50 pt-24 pb-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <h1 className="text-4xl md:text-5xl font-serif text-stone-900 mb-6">Privacy Policy</h1>
          <p className="text-lg text-stone-600 max-w-2xl mx-auto">
            At PillarstoHome Real Estate, we take your privacy seriously. This policy outlines how we protect and manage your personal information with the utmost discretion.
          </p>
          <p className="text-sm text-stone-500 mt-4">Last Updated: March 24, 2026</p>
        </motion.div>

        <div className="space-y-12">
          {sections.map((section, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-white p-8 rounded-2xl shadow-sm border border-stone-100"
            >
              <div className="flex items-start gap-4">
                <div className="p-3 bg-stone-50 rounded-xl">
                  {section.icon}
                </div>
                <div>
                  <h2 className="text-2xl font-serif text-stone-900 mb-4">{section.title}</h2>
                  <p className="text-stone-600 leading-relaxed">
                    {section.content}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-16 p-8 bg-luxury-900 text-white rounded-2xl text-center"
        >
          <h2 className="text-2xl font-serif mb-4">Questions About Your Privacy?</h2>
          <p className="text-stone-300 mb-6">
            Our dedicated privacy team is here to help you understand how we protect your data.
          </p>
          <Link 
            to="/contact" 
            className="inline-block px-8 py-3 bg-gold-500 text-white font-medium rounded-full hover:bg-gold-600 transition-colors"
          >
            Contact Privacy Team
          </Link>
        </motion.div>
      </div>
    </main>
  );
};

export default Privacy;
