import React, { useState } from 'react';
import { Sparkles, Loader2, Download, RefreshCw, Wand2, Camera, Palette, Home } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export const DreamHomeVisualizer = () => {
  const [style, setStyle] = useState('Modern Minimalist');
  const [room, setRoom] = useState('Living Room');
  const [vibe, setVibe] = useState('Sunset Gold');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const styles = ['Modern Minimalist', 'Classic European', 'Industrial Loft', 'Tropical Zen', 'Art Deco'];
  const rooms = ['Living Room', 'Master Bedroom', 'Kitchen', 'Home Theater', 'Private Gym', 'Infinity Pool Area'];
  const vibes = ['Sunset Gold', 'Ocean Breeze', 'Midnight Velvet', 'Forest Sanctuary', 'Desert Mirage'];

  const generateConcept = async () => {
    setIsGenerating(true);
    setError(null);
    try {
      const prompt = `A high-end, ultra-luxury ${style} ${room} with a ${vibe} color palette. 
      The space should feature premium materials like Italian marble, brushed gold accents, and floor-to-ceiling windows with a breathtaking view. 
      Professional architectural photography, 8k resolution, cinematic lighting, photorealistic.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: [{ text: prompt }],
        config: {
          imageConfig: {
            aspectRatio: "16:9",
            imageSize: "1K"
          }
        }
      });

      let imageUrl = null;
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          imageUrl = `data:image/png;base64,${part.inlineData.data}`;
          break;
        }
      }

      if (imageUrl) {
        setGeneratedImage(imageUrl);
      } else {
        throw new Error("No image data returned from AI");
      }
    } catch (err) {
      console.error("Generation error:", err);
      setError("Our AI concierge is currently busy. Please try again in a moment.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="bg-luxury-800/50 border border-white/10 rounded-3xl overflow-hidden shadow-2xl">
      <div className="p-6 md:p-8 border-b border-white/10 bg-luxury-900/50">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-gold-500/10 text-gold-500 rounded-lg">
            <Sparkles size={20} />
          </div>
          <h2 className="text-xl md:text-2xl font-serif text-white">Dream Home Visualizer</h2>
        </div>
        <p className="text-gray-400 text-xs md:text-sm">Use our AI to visualize your future luxury living space.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2">
        <div className="p-6 md:p-8 space-y-8 border-r border-white/10">
          <div className="space-y-6">
            <div>
              <label className="flex items-center gap-2 text-xs uppercase tracking-widest text-gray-500 mb-4">
                <Palette size={14} /> Architectural Style
              </label>
              <div className="flex flex-wrap gap-2">
                {styles.map(s => (
                  <button 
                    key={s}
                    onClick={() => setStyle(s)}
                    className={`px-4 py-2 rounded-full text-xs font-medium transition-all ${style === s ? 'bg-gold-500 text-black shadow-lg shadow-gold-500/20' : 'bg-luxury-900 text-gray-400 hover:text-white border border-white/5'}`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="flex items-center gap-2 text-xs uppercase tracking-widest text-gray-500 mb-4">
                <Home size={14} /> Select Space
              </label>
              <div className="flex flex-wrap gap-2">
                {rooms.map(r => (
                  <button 
                    key={r}
                    onClick={() => setRoom(r)}
                    className={`px-4 py-2 rounded-full text-xs font-medium transition-all ${room === r ? 'bg-gold-500 text-black shadow-lg shadow-gold-500/20' : 'bg-luxury-900 text-gray-400 hover:text-white border border-white/5'}`}
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="flex items-center gap-2 text-xs uppercase tracking-widest text-gray-500 mb-4">
                <Wand2 size={14} /> Color Vibe
              </label>
              <div className="flex flex-wrap gap-2">
                {vibes.map(v => (
                  <button 
                    key={v}
                    onClick={() => setVibe(v)}
                    className={`px-4 py-2 rounded-full text-xs font-medium transition-all ${vibe === v ? 'bg-gold-500 text-black shadow-lg shadow-gold-500/20' : 'bg-luxury-900 text-gray-400 hover:text-white border border-white/5'}`}
                  >
                    {v}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button 
            onClick={generateConcept}
            disabled={isGenerating}
            className="w-full py-4 bg-white text-black font-bold rounded-xl hover:bg-gold-500 transition-all flex items-center justify-center gap-3 group disabled:opacity-50"
          >
            {isGenerating ? (
              <>
                <Loader2 size={20} className="animate-spin" />
                Architecting your vision...
              </>
            ) : (
              <>
                <Camera size={20} className="group-hover:rotate-12 transition-transform" />
                Generate AI Concept
              </>
            )}
          </button>

          {error && (
            <p className="text-red-400 text-xs text-center italic">{error}</p>
          )}
        </div>

        <div className="bg-black/40 relative min-h-[400px] flex items-center justify-center group">
          <AnimatePresence mode="wait">
            {generatedImage ? (
              <motion.div 
                key="image"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="w-full h-full relative"
              >
                <img 
                  src={generatedImage} 
                  alt="AI Concept" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                  <a 
                    href={generatedImage} 
                    download={`pillarstohome-concept-${style.toLowerCase()}.png`}
                    className="p-3 bg-white/10 backdrop-blur-md rounded-full text-white hover:bg-gold-500 hover:text-black transition-all"
                  >
                    <Download size={20} />
                  </a>
                  <button 
                    onClick={generateConcept}
                    className="p-3 bg-white/10 backdrop-blur-md rounded-full text-white hover:bg-gold-500 hover:text-black transition-all"
                  >
                    <RefreshCw size={20} />
                  </button>
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="placeholder"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center p-12 space-y-6"
              >
                <div className="w-24 h-24 bg-luxury-900 rounded-full flex items-center justify-center mx-auto border border-white/5 text-gray-700">
                  <Home size={40} />
                </div>
                <div>
                  <p className="text-white font-serif text-xl mb-2">Your Vision Awaits</p>
                  <p className="text-gray-500 text-sm max-w-xs mx-auto">
                    Select your preferences and let our AI architect a unique concept for your future residence.
                  </p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
          
          {isGenerating && (
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center">
              <div className="text-center space-y-4">
                <div className="w-12 h-12 border-2 border-gold-500 border-t-transparent rounded-full animate-spin mx-auto"></div>
                <p className="text-gold-500 font-serif tracking-widest uppercase text-xs">Generating Masterpiece</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
