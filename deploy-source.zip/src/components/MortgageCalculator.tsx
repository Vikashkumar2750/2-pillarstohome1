import React, { useState, useEffect } from 'react';
import { Calculator, DollarSign, Percent, Calendar, Info } from 'lucide-react';
import { motion } from 'framer-motion';
import { useCurrency } from '../contexts/CurrencyContext';

interface MortgageCalculatorProps {
  propertyPrice: string;
}

export const MortgageCalculator: React.FC<MortgageCalculatorProps> = ({ propertyPrice }) => {
  const { formatPrice } = useCurrency();
  // Extract number from price string like "$12,500,000"
  const numericPrice = parseInt(propertyPrice.replace(/[^0-9]/g, '')) || 1000000;
  
  const [downPayment, setDownPayment] = useState(numericPrice * 0.2);
  const [interestRate, setInterestRate] = useState(4.5);
  const [loanTerm, setLoanTerm] = useState(30);
  const [monthlyPayment, setMonthlyPayment] = useState(0);

  useEffect(() => {
    const principal = numericPrice - downPayment;
    const monthlyRate = interestRate / 100 / 12;
    const numberOfPayments = loanTerm * 12;
    
    if (monthlyRate === 0) {
      setMonthlyPayment(principal / numberOfPayments);
    } else {
      const payment = (principal * monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
      setMonthlyPayment(payment);
    }
  }, [numericPrice, downPayment, interestRate, loanTerm]);

  return (
    <div className="bg-luxury-800/50 border border-white/5 rounded-3xl p-8 shadow-2xl">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-2 bg-gold-500/10 text-gold-500 rounded-lg">
          <Calculator size={20} />
        </div>
        <h3 className="text-xl font-serif text-white">Mortgage Estimator</h3>
      </div>

      <div className="space-y-6">
        <div>
          <div className="flex justify-between mb-2">
            <label className="text-xs uppercase tracking-widest text-gray-500">Down Payment</label>
            <span className="text-gold-500 font-medium">{formatPrice(downPayment.toLocaleString())}</span>
          </div>
          <input 
            type="range" 
            min="0" 
            max={numericPrice} 
            step={numericPrice / 100}
            value={downPayment}
            onChange={(e) => setDownPayment(parseInt(e.target.value))}
            className="w-full h-1 bg-luxury-900 rounded-lg appearance-none cursor-pointer accent-gold-500"
          />
          <div className="flex justify-between mt-1 text-[10px] text-gray-600">
            <span>0%</span>
            <span>{Math.round((downPayment / numericPrice) * 100)}%</span>
            <span>100%</span>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="text-xs uppercase tracking-widest text-gray-500 block mb-2">Interest Rate</label>
            <div className="relative">
              <Percent className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={14} />
              <input 
                type="number" 
                value={interestRate}
                onChange={(e) => setInterestRate(parseFloat(e.target.value))}
                className="w-full bg-luxury-900 border border-white/10 rounded-xl pl-10 pr-4 py-2 text-sm text-white focus:outline-none focus:border-gold-500"
                step="0.1"
              />
            </div>
          </div>
          <div>
            <label className="text-xs uppercase tracking-widest text-gray-500 block mb-2">Loan Term</label>
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500" size={14} />
              <select 
                value={loanTerm}
                onChange={(e) => setLoanTerm(parseInt(e.target.value))}
                className="w-full bg-luxury-900 border border-white/10 rounded-xl pl-10 pr-4 py-2 text-sm text-white focus:outline-none focus:border-gold-500 appearance-none"
              >
                <option value={15}>15 Years</option>
                <option value={20}>20 Years</option>
                <option value={30}>30 Years</option>
              </select>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5">
          <div className="flex justify-between items-end mb-2">
            <span className="text-gray-400 text-sm">Estimated Monthly Payment</span>
            <span className="text-3xl font-serif text-white">{formatPrice(Math.round(monthlyPayment).toLocaleString())}</span>
          </div>
          <p className="text-[10px] text-gray-600 leading-relaxed italic">
            *This is an estimate only. Actual rates and payments may vary based on credit score, taxes, and insurance.
          </p>
        </div>

        <button className="w-full py-3 bg-gold-500/10 text-gold-500 border border-gold-500/20 rounded-xl text-sm font-bold hover:bg-gold-500 hover:text-black transition-all flex items-center justify-center gap-2">
          <Info size={16} /> Get Pre-Approved
        </button>
      </div>
    </div>
  );
};
