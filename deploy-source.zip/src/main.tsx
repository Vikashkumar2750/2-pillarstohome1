import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { CurrencyProvider } from './contexts/CurrencyContext';

// Global HTTP interceptor explicitly ensuring all local API calls hit the remote backend server!
if (import.meta.env.VITE_API_URL) {
  const originalFetch = window.fetch;
  window.fetch = async function () {
    let args = Array.prototype.slice.call(arguments);
    if (typeof args[0] === 'string' && args[0].startsWith('/api/')) {
      args[0] = import.meta.env.VITE_API_URL + args[0];
    }
    return originalFetch.apply(this, args as any);
  };
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <CurrencyProvider>
      <App />
    </CurrencyProvider>
  </StrictMode>,
);
