import { useState, useEffect, useCallback } from 'react';

export interface ContentItem {
  id: number;
  page: string;
  section: string;
  key: string;
  value: string;
  type: 'text' | 'html' | 'image' | 'video' | 'link';
  description: string;
}

export const useContent = (page?: string) => {
  const [content, setContent] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchContent = useCallback(async () => {
    try {
      setLoading(true);
      const url = page ? `/api/content?page=${page}` : '/api/content';
      const response = await fetch(url);
      if (!response.ok) throw new Error('Failed to fetch content');
      const data: any = await response.json();
      
      const contentMap: Record<string, string> = {};
      if (Array.isArray(data)) {
        data.forEach((item: ContentItem) => {
          contentMap[`${item.section}_${item.key}`] = item.value;
        });
      } else {
        console.error('Failed to load content, expected array but got:', data);
      }
      
      setContent(contentMap);
    } catch (err) {
      console.error('Error loading content:', err);
      setError('Failed to load content');
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => {
    fetchContent();
  }, [fetchContent]);

  return { content, loading, error, refresh: fetchContent };
};
